"""اضافه کردن جدول cart_items.

Revision ID: 0002_cart_items
Revises: 0001_initial
Create Date: 2024-01-15 00:00:00

"""
from alembic import op
import sqlalchemy as sa


revision = "0002_cart_items"
down_revision = "0001_initial"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "cart_items",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column(
            "user_id",
            sa.String(length=36),
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "product_id",
            sa.Integer(),
            sa.ForeignKey("products.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("quantity", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("price_snapshot", sa.BigInteger(), nullable=False, server_default="0"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.UniqueConstraint("user_id", "product_id", name="uq_cart_user_product"),
        sa.CheckConstraint("quantity > 0", name="ck_cart_qty_positive"),
    )
    op.create_index("ix_cart_items_user_id", "cart_items", ["user_id"])
    op.create_index("ix_cart_items_product_id", "cart_items", ["product_id"])
    op.create_index("ix_cart_items_user_updated", "cart_items", ["user_id", "updated_at"])


def downgrade() -> None:
    op.drop_index("ix_cart_items_user_updated", "cart_items")
    op.drop_index("ix_cart_items_product_id", "cart_items")
    op.drop_index("ix_cart_items_user_id", "cart_items")
    op.drop_table("cart_items")
