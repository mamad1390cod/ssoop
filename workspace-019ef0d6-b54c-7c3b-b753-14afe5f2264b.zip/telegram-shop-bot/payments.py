"""سرویس پرداخت - کارت به کارت و درگاه آنلاین

هماهنگ با OrderService جدید که total_amount ثابت نگه می‌دارد.
"""
import logging
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import aiohttp

import config
from database import get_session
from models import Order, Payment, PaymentReceipt, User
from order_service import OrderService
from utils import encrypt, file_hash


logger = logging.getLogger(__name__)


# ============== کارت به کارت ==============

async def submit_card_payment(
    order: Order,
    user: User,
    *,
    file_bytes: bytes,
    file_name: str,
    mime_type: str,
    telegram_file_id: Optional[str] = None,
    tracking_code: Optional[str] = None,
    ip_address: Optional[str] = None,
) -> tuple[Optional[Payment], str]:
    """ثبت پرداخت کارت به کارت.

    Returns: (payment, error_message)
    """
    # بررسی فیش تکراری
    h = file_hash(file_bytes)

    async with get_session() as session:
        # بررسی فیش تکراری برای همین کاربر
        from sqlalchemy import select

        result = await session.execute(
            select(PaymentReceipt).where(
                PaymentReceipt.user_id == user.id,
                PaymentReceipt.file_hash == h,
            )
        )
        existing = result.scalar_one_or_none()
        if existing:
            return None, "این فیش قبلاً ارسال شده است"

        # ذخیره فایل فیش
        safe_name = f"{order.order_number}_{file_name}"
        dest = config.RECEIPTS_DIR / safe_name
        dest.write_bytes(file_bytes)

        # ساخت رکورد فیش
        receipt = PaymentReceipt(
            user_id=user.id,
            order_id=order.id,
            file_path=str(dest),
            file_id=telegram_file_id,
            file_hash=h,
            file_size=len(file_bytes),
            mime_type=mime_type,
            amount=order.total_amount,
            tracking_code=tracking_code,
            uploaded_at=datetime.now(timezone.utc),
            ip_address=ip_address,
            submitted_via="telegram",
        )
        session.add(receipt)
        await session.flush()
        receipt_id = receipt.id

        # ساخت رکورد پرداخت
        payment = Payment(
            order_id=order.id,
            user_id=user.id,
            method="card_to_card",
            status="pending",
            amount=order.total_amount,
            transaction_id=f"CC-{order.order_number}",
            tracking_code_encrypted=encrypt(tracking_code) if tracking_code else None,
            receipt_id=receipt_id,
            ip_address=ip_address,
        )
        session.add(payment)
        await session.flush()
        payment_id = payment.id

    logger.info(
        f"Card payment submitted: order={order.order_number} "
        f"user={user.telegram_id} payment_id={payment_id}"
    )
    # بازگشت payment با eager load برای order
    return await _get_payment(payment_id), ""


async def _get_payment(payment_id: int) -> Optional[Payment]:
    """دریافت payment با eager load."""
    from sqlalchemy.orm import joinedload

    async with get_session() as session:
        result = await session.execute(
            select(Payment)
            .options(joinedload(Payment.order), joinedload(Payment.user))
            .where(Payment.id == payment_id)
        )
        return result.scalar_one_or_none()


async def approve_payment(
    payment_id: int,
    *,
    changed_by: Optional[str] = None,
    changed_by_telegram_id: Optional[int] = None,
) -> Optional[Order]:
    """تایید پرداخت کارت به کارت.

    از OrderService برای تغییر وضعیت استفاده می‌کند.
    """
    async with get_session() as session:
        payment = await session.get(Payment, payment_id)
        if not payment:
            return None
        if payment.status != "pending":
            # قبلاً تایید شده - فقط برگردان
            order = await session.get(Order, payment.order_id)
            return order
        # به‌روزرسانی payment
        from sqlalchemy import update
        await session.execute(
            update(Payment)
            .where(Payment.id == payment_id)
            .values(
                status="success",
                verified_at=datetime.now(timezone.utc),
                verified_by=changed_by,
                verified_by_telegram_id=changed_by_telegram_id,
            )
        )
        order_id = payment.order_id

    # تغییر وضعیت سفارش به PAID (از OrderService)
    order = await OrderService.approve_payment(
        order_id,
        changed_by=changed_by,
        changed_by_telegram_id=changed_by_telegram_id,
    )

    if order:
        # بروزرسانی کاربر
        async with get_session() as session:
            user = await session.get(User, order.user_id)
            if user:
                user.total_spent += order.total_amount
                user.last_activity_at = datetime.now(timezone.utc)
                # بررسی وفاداری
                from models import UserLevel

                new_total = user.total_spent
                if new_total >= 2_000_000:
                    user.level = UserLevel.PLATINUM
                elif new_total >= 500_000:
                    user.level = UserLevel.GOLD
                elif new_total >= 100_000:
                    user.level = UserLevel.SILVER

        # کاهش موجودی محصولات (اگر قبلاً کاهش نیافته)
        async with get_session() as session:
            from sqlalchemy import select

            result = await session.execute(
                select(OrderItem).where(OrderItem.order_id == order_id)
            )
            items = result.scalars().all()
            for item in items:
                product = await session.get(Product, item.product_id)
                if product and product.track_inventory:
                    product.stock = max(0, product.stock - item.quantity)
                    product.purchase_count += item.quantity

    return order


async def reject_payment(
    payment_id: int,
    reason: str,
    *,
    changed_by: Optional[str] = None,
    changed_by_telegram_id: Optional[int] = None,
) -> Optional[Order]:
    """رد پرداخت کارت به کارت."""
    async with get_session() as session:
        from sqlalchemy import update

        payment = await session.get(Payment, payment_id)
        if not payment:
            return None
        order_id = payment.order_id
        await session.execute(
            update(Payment)
            .where(Payment.id == payment_id)
            .values(
                status="failed",
                rejection_reason=reason,
                rejected_at=datetime.now(timezone.utc),
                verified_by=changed_by,
                verified_by_telegram_id=changed_by_telegram_id,
            )
        )
        order = await session.get(Order, order_id)
        return order


# ============== درگاه آنلاین ==============

async def create_online_payment(order: Order) -> tuple[bool, str, Optional[str]]:
    """ساخت پرداخت آنلاین و دریافت لینک درگاه."""
    if not config.PAYMENT_MERCHANT_ID:
        return False, "درگاه پرداخت پیکربندی نشده", None

    if config.PAYMENT_GATEWAY_TYPE == "zarinpal":
        return await _zarinpal_request(order)
    return False, f"درگاه {config.PAYMENT_GATEWAY_TYPE} پشتیبانی نمی‌شود", None


async def _zarinpal_request(order: Order) -> tuple[bool, str, Optional[str]]:
    """درخواست پرداخت به زرین‌پال."""
    url = "https://api.zarinpal.com/pg/v4/payment/request.json"
    payload = {
        "merchant_id": config.PAYMENT_MERCHANT_ID,
        "amount": order.total_amount * 10,  # ریال
        "callback_url": config.PAYMENT_CALLBACK_URL or "https://example.com/callback",
        "description": f"پرداخت سفارش {order.order_number}",
        "metadata": {
            "order_id": str(order.id),
            "order_number": order.order_number,
        },
    }
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload, timeout=30) as resp:
                data = await resp.json(content_type=None)
    except Exception as e:
        logger.error(f"Zarinpal request failed: {e}")
        return False, "خطا در اتصال به درگاه", None

    if data.get("data", {}).get("code") not in (100,):
        return False, "خطا از سمت درگاه", None

    authority = data["data"]["authority"]
    redirect_url = f"https://www.zarinpal.com/pg/StartPay/{authority}"
    return True, "", redirect_url


async def verify_online_payment(authority: str, amount: int) -> tuple[bool, str]:
    """تایید پرداخت آنلاین."""
    url = "https://api.zarinpal.com/pg/v4/payment/verify.json"
    payload = {
        "merchant_id": config.PAYMENT_MERCHANT_ID,
        "amount": amount * 10,
        "authority": authority,
    }
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload, timeout=30) as resp:
                data = await resp.json(content_type=None)
    except Exception as e:
        logger.error(f"Zarinpal verify failed: {e}")
        return False, "خطا در تایید"

    code = data.get("data", {}).get("code")
    if code in (100, 101):
        return True, str(data["data"].get("ref_id", ""))
    return False, "پرداخت تایید نشد"
