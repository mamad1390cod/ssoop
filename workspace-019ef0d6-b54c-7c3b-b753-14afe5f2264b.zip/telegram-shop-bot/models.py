"""مدل‌های دیتابیس - Production Ready

تمام جداول با ایندکس‌های مناسب، constraint‌ها و timestamps.
"""
from datetime import datetime, timezone
from enum import Enum
from typing import Optional

from sqlalchemy import (
    BigInteger,
    Boolean,
    CheckConstraint,
    DateTime,
    Enum as SAEnum,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


def utc_now() -> datetime:
    """زمان فعلی UTC (timezone-aware)."""
    return datetime.now(timezone.utc)


# ============== Enum‌ها ==============

class UserRole(str, Enum):
    USER = "user"
    VIP = "vip"
    PREMIUM = "premium"
    ADMIN = "admin"
    SUPER_ADMIN = "super_admin"


class UserLevel(str, Enum):
    BRONZE = "bronze"
    SILVER = "silver"
    GOLD = "gold"
    PLATINUM = "platinum"


class DiscountType(str, Enum):
    PERCENTAGE = "percentage"
    FIXED_AMOUNT = "fixed_amount"


class OrderStatus(str, Enum):
    """وضعیت‌های سفارش - ۷ وضعیت"""
    PENDING_PAYMENT = "pending_payment"     # در انتظار پرداخت
    PAID = "paid"                            # پرداخت شده
    PROCESSING = "processing"                # در حال پردازش
    READY_TO_SHIP = "ready_to_ship"          # آماده ارسال
    SHIPPED = "shipped"                      # ارسال شده
    COMPLETED = "completed"                  # تکمیل شده
    CANCELLED = "cancelled"                  # لغو شده


# وضعیت‌هایی که سفارش هنوز "فعال" است (نیاز به اقدام دارند)
ACTIVE_ORDER_STATUSES = {
    OrderStatus.PENDING_PAYMENT.value,
    OrderStatus.PAID.value,
    OrderStatus.PROCESSING.value,
    OrderStatus.READY_TO_SHIP.value,
}

# وضعیت‌های آرشیو (تکمیل شده)
ARCHIVED_ORDER_STATUSES = {
    OrderStatus.SHIPPED.value,
    OrderStatus.COMPLETED.value,
    OrderStatus.CANCELLED.value,
}

# وضعیت‌هایی که در آمار فروش حساب می‌شوند
SALES_COUNTED_STATUSES = {
    OrderStatus.PAID.value,
    OrderStatus.PROCESSING.value,
    OrderStatus.READY_TO_SHIP.value,
    OrderStatus.SHIPPED.value,
    OrderStatus.COMPLETED.value,
}

ORDER_STATUS_LABELS = {
    OrderStatus.PENDING_PAYMENT.value: "⏳ در انتظار پرداخت",
    OrderStatus.PAID.value: "💳 پرداخت شده",
    OrderStatus.PROCESSING.value: "🔄 در حال پردازش",
    OrderStatus.READY_TO_SHIP.value: "📦 آماده ارسال",
    OrderStatus.SHIPPED.value: "🚚 ارسال شده",
    OrderStatus.COMPLETED.value: "✅ تکمیل شده",
    OrderStatus.CANCELLED.value: "❌ لغو شده",
}


class PaymentMethod(str, Enum):
    ONLINE = "online"
    CARD_TO_CARD = "card_to_card"


class PaymentStatus(str, Enum):
    PENDING = "pending"
    SUCCESS = "success"
    FAILED = "failed"
    CANCELLED = "cancelled"
    REFUNDED = "refunded"


# ============== کاربر ==============

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True)
    username: Mapped[Optional[str]] = mapped_column(String(64))
    first_name: Mapped[Optional[str]] = mapped_column(String(128))
    last_name: Mapped[Optional[str]] = mapped_column(String(128))
    full_name: Mapped[Optional[str]] = mapped_column(String(256))
    phone: Mapped[Optional[str]] = mapped_column(String(32))
    email: Mapped[Optional[str]] = mapped_column(String(128))
    language_code: Mapped[str] = mapped_column(String(8), default="fa")

    role: Mapped[UserRole] = mapped_column(
        SAEnum(UserRole, name="user_role"),
        default=UserRole.USER,
    )
    level: Mapped[UserLevel] = mapped_column(
        SAEnum(UserLevel, name="user_level"),
        default=UserLevel.BRONZE,
    )

    is_blocked: Mapped[bool] = mapped_column(Boolean, default=False)
    is_verified: Mapped[bool] = mapped_column(Boolean, default=False)

    loyalty_points: Mapped[int] = mapped_column(Integer, default=0)
    total_spent: Mapped[int] = mapped_column(BigInteger, default=0)
    orders_count: Mapped[int] = mapped_column(Integer, default=0)

    last_activity_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    registered_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)

    metadata_json: Mapped[Optional[str]] = mapped_column(Text)
    notes: Mapped[Optional[str]] = mapped_column(Text)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, onupdate=utc_now)
    is_deleted: Mapped[bool] = mapped_column(Boolean, default=False)
    deleted_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    # روابط
    addresses: Mapped[list["UserAddress"]] = relationship(
        back_populates="user", cascade="all, delete-orphan"
    )
    orders: Mapped[list["Order"]] = relationship(
        back_populates="user"
    )
    cart_items: Mapped[list["CartItem"]] = relationship(
        back_populates="user", cascade="all, delete-orphan"
    )

    @property
    def display_name(self) -> str:
        if self.full_name:
            return self.full_name
        parts = [self.first_name or "", self.last_name or ""]
        name = " ".join(p for p in parts if p).strip()
        if name:
            return name
        if self.username:
            return f"@{self.username}"
        return f"User {self.telegram_id}"


class UserAddress(Base):
    __tablename__ = "user_addresses"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )

    title: Mapped[str] = mapped_column(String(64))
    full_name: Mapped[str] = mapped_column(String(256))
    phone: Mapped[str] = mapped_column(String(32))
    province: Mapped[str] = mapped_column(String(64))
    city: Mapped[str] = mapped_column(String(64))
    address_line: Mapped[str] = mapped_column(Text)
    postal_code: Mapped[str] = mapped_column(String(20))
    is_default: Mapped[bool] = mapped_column(Boolean, default=False)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, onupdate=utc_now)
    is_deleted: Mapped[bool] = mapped_column(Boolean, default=False)
    deleted_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    user: Mapped["User"] = relationship(back_populates="addresses")


# ============== دسته‌بندی ==============

class Category(Base):
    __tablename__ = "categories"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(128))
    slug: Mapped[Optional[str]] = mapped_column(String(128), unique=True)
    description: Mapped[Optional[str]] = mapped_column(Text)
    image_url: Mapped[Optional[str]] = mapped_column(String(512))
    icon: Mapped[Optional[str]] = mapped_column(String(16), default="📂")

    parent_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("categories.id", ondelete="SET NULL")
    )
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, onupdate=utc_now)
    is_deleted: Mapped[bool] = mapped_column(Boolean, default=False)
    deleted_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    products: Mapped[list["Product"]] = relationship(back_populates="category")


# ============== محصول ==============

class Product(Base):
    __tablename__ = "products"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    sku: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    slug: Mapped[str] = mapped_column(String(256), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(256))
    short_description: Mapped[Optional[str]] = mapped_column(String(512))
    description: Mapped[Optional[str]] = mapped_column(Text)

    category_id: Mapped[int] = mapped_column(
        ForeignKey("categories.id", ondelete="RESTRICT"), index=True
    )

    # قیمت‌ها (هرگز تغییر نمی‌کنند بعد از سفارش)
    price: Mapped[int] = mapped_column(BigInteger)
    cost_price: Mapped[Optional[int]] = mapped_column(BigInteger)

    # موجودی
    stock: Mapped[int] = mapped_column(Integer, default=0)
    low_stock_threshold: Mapped[int] = mapped_column(Integer, default=5)
    track_inventory: Mapped[bool] = mapped_column(Boolean, default=True)

    # پرچم‌ها
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_featured: Mapped[bool] = mapped_column(Boolean, default=False)
    is_bestseller: Mapped[bool] = mapped_column(Boolean, default=False)
    is_new: Mapped[bool] = mapped_column(Boolean, default=True)
    is_vip_only: Mapped[bool] = mapped_column(Boolean, default=False)

    # آمار
    view_count: Mapped[int] = mapped_column(Integer, default=0)
    purchase_count: Mapped[int] = mapped_column(Integer, default=0)
    rating: Mapped[float] = mapped_column(default=0.0)
    reviews_count: Mapped[int] = mapped_column(Integer, default=0)

    # تصاویر
    image_url: Mapped[Optional[str]] = mapped_column(String(512))
    images_json: Mapped[Optional[str]] = mapped_column(Text)  # JSON لیست تصاویر

    # وزن
    weight_grams: Mapped[Optional[int]] = mapped_column(Integer)
    dimensions: Mapped[Optional[str]] = mapped_column(String(64))

    tags: Mapped[Optional[str]] = mapped_column(String(512))

    # تخفیف
    discount_price: Mapped[Optional[int]] = mapped_column(BigInteger)
    discount_percent: Mapped[Optional[int]] = mapped_column(Integer)
    discount_starts_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    discount_ends_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    # SEO
    meta_title: Mapped[Optional[str]] = mapped_column(String(256))
    meta_description: Mapped[Optional[str]] = mapped_column(Text)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, onupdate=utc_now)
    is_deleted: Mapped[bool] = mapped_column(Boolean, default=False)
    deleted_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    category: Mapped["Category"] = relationship(back_populates="products")

    @property
    def effective_price(self) -> int:
        """قیمت فعلی محصول (با احتساب تخفیف)."""
        if self.discount_price and self.discount_price < self.price:
            # بررسی زمان تخفیف
            now = utc_now()
            if self.discount_starts_at and self.discount_starts_at.tzinfo is None:
                ds = self.discount_starts_at.replace(tzinfo=timezone.utc)
            else:
                ds = self.discount_starts_at
            if self.discount_ends_at and self.discount_ends_at.tzinfo is None:
                de = self.discount_ends_at.replace(tzinfo=timezone.utc)
            else:
                de = self.discount_ends_at
            if ds and ds > now:
                return self.price
            if de and de < now:
                return self.price
            return self.discount_price
        return self.price

    @property
    def is_on_sale(self) -> bool:
        return self.effective_price < self.price

    @property
    def is_in_stock(self) -> bool:
        return self.track_inventory and self.stock > 0


# ============== سبد خرید (persistent) ==============

class CartItem(Base):
    """آیتم‌های سبد خرید کاربران - ذخیره در دیتابیس."""

    __tablename__ = "cart_items"
    __table_args__ = (
        UniqueConstraint("user_id", "product_id", name="uq_cart_user_product"),
        Index("ix_cart_user_active", "user_id", "updated_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    product_id: Mapped[int] = mapped_column(
        ForeignKey("products.id", ondelete="CASCADE"), index=True
    )
    quantity: Mapped[int] = mapped_column(Integer, default=1)

    # قیمت در زمان اضافه به سبد (snapshot - در برابر تغییرات قیمت)
    price_snapshot: Mapped[int] = mapped_column(BigInteger, default=0)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, onupdate=utc_now)

    # روابط
    user: Mapped["User"] = relationship(back_populates="cart_items")
    product: Mapped["Product"] = relationship()

    __table_args_constraints__ = (
        CheckConstraint("quantity > 0", name="ck_cart_qty_positive"),
    )


# ============== سفارش ==============

class Order(Base):
    """سفارش - total_amount پس از ایجاد تغییر نمی‌کند."""

    __tablename__ = "orders"
    __table_args__ = (
        Index("ix_orders_user_status", "user_id", "status"),
        Index("ix_orders_status_paid_at", "status", "paid_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    order_number: Mapped[str] = mapped_column(String(32), unique=True, index=True)

    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), index=True
    )

    # وضعیت - این فیلد تغییر می‌کند ولی total_amount ثابت می‌ماند
    status: Mapped[str] = mapped_column(
        String(32),
        default=OrderStatus.PENDING_PAYMENT.value,
        index=True,
    )

    # === فیلدهای مالی (هرگز تغییر نمی‌کنند بعد از ایجاد سفارش) ===
    subtotal: Mapped[int] = mapped_column(BigInteger)
    discount_amount: Mapped[int] = mapped_column(BigInteger, default=0)
    shipping_cost: Mapped[int] = mapped_column(BigInteger, default=0)
    tax_amount: Mapped[int] = mapped_column(BigInteger, default=0)
    total_amount: Mapped[int] = mapped_column(BigInteger)  # مبلغ نهایی - ثابت
    final_amount: Mapped[int] = mapped_column(BigInteger)  # همان total_amount

    coupon_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("coupons.id", ondelete="SET NULL")
    )
    coupon_code: Mapped[Optional[str]] = mapped_column(String(32))

    # === اطلاعات ارسال (snapshot) ===
    shipping_name: Mapped[str] = mapped_column(String(128))
    shipping_phone: Mapped[str] = mapped_column(String(32))
    shipping_province: Mapped[str] = mapped_column(String(64))
    shipping_city: Mapped[str] = mapped_column(String(64))
    shipping_address: Mapped[str] = mapped_column(Text)
    shipping_postal_code: Mapped[str] = mapped_column(String(20))

    # === پرداخت ===
    payment_method: Mapped[Optional[str]] = mapped_column(String(32))
    tracking_code: Mapped[Optional[str]] = mapped_column(String(64))
    receipt_file_id: Mapped[Optional[str]] = mapped_column(String(256))

    # === تایم‌استمپ‌ها ===
    paid_at: Mapped[Optional[datetime]] = mapped_column(DateTime, index=True)
    shipped_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    delivered_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    cancelled_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    # === یادداشت‌ها ===
    customer_notes: Mapped[Optional[str]] = mapped_column(Text)
    admin_notes: Mapped[Optional[str]] = mapped_column(Text)
    cancel_reason: Mapped[Optional[str]] = mapped_column(Text)

    # === متادیتا ===
    metadata_json: Mapped[Optional[str]] = mapped_column(Text)
    ip_address: Mapped[Optional[str]] = mapped_column(String(64))
    user_agent: Mapped[Optional[str]] = mapped_column(String(256))

    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, onupdate=utc_now)
    is_deleted: Mapped[bool] = mapped_column(Boolean, default=False)
    deleted_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    # روابط
    user: Mapped["User"] = relationship(back_populates="orders")
    items: Mapped[list["OrderItem"]] = relationship(
        back_populates="order",
        cascade="all, delete-orphan",
    )
    payments: Mapped[list["Payment"]] = relationship(
        back_populates="order",
        cascade="all, delete-orphan",
    )
    status_history: Mapped[list["OrderStatusHistory"]] = relationship(
        back_populates="order",
        cascade="all, delete-orphan",
        order_by="OrderStatusHistory.changed_at",
    )


class OrderItem(Base):
    """اقلام سفارش - snapshot محصول."""

    __tablename__ = "order_items"
    __table_args__ = (
        Index("ix_order_items_order_id", "order_id"),
        Index("ix_order_items_product_id", "product_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    order_id: Mapped[int] = mapped_column(
        ForeignKey("orders.id", ondelete="CASCADE")
    )
    product_id: Mapped[int] = mapped_column(
        ForeignKey("products.id", ondelete="RESTRICT")
    )

    # Snapshot
    product_name: Mapped[str] = mapped_column(String(256))
    product_sku: Mapped[str] = mapped_column(String(64))
    product_image_url: Mapped[Optional[str]] = mapped_column(String(512))

    quantity: Mapped[int] = mapped_column(Integer)
    unit_price: Mapped[int] = mapped_column(BigInteger)
    total_price: Mapped[int] = mapped_column(BigInteger)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)

    order: Mapped["Order"] = relationship(back_populates="items")
    product: Mapped["Product"] = relationship()


class OrderStatusHistory(Base):
    """تاریخچه تغییرات وضعیت - برای audit."""

    __tablename__ = "order_status_history"
    __table_args__ = (
        Index("ix_status_history_order", "order_id", "changed_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    order_id: Mapped[int] = mapped_column(
        ForeignKey("orders.id", ondelete="CASCADE"), index=True
    )
    from_status: Mapped[Optional[str]] = mapped_column(String(32))
    to_status: Mapped[str] = mapped_column(String(32))
    changed_by: Mapped[Optional[str]] = mapped_column(String(64))
    changed_by_telegram_id: Mapped[Optional[int]] = mapped_column(BigInteger)
    reason: Mapped[Optional[str]] = mapped_column(Text)
    note: Mapped[Optional[str]] = mapped_column(Text)
    changed_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)

    order: Mapped["Order"] = relationship(back_populates="status_history")


# ============== کد تخفیف ==============

class Coupon(Base):
    __tablename__ = "coupons"
    __table_args__ = (
        Index("ix_coupons_active_valid", "is_active", "valid_from", "valid_until"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(128))
    description: Mapped[Optional[str]] = mapped_column(Text)

    discount_type: Mapped[DiscountType] = mapped_column(
        SAEnum(DiscountType, name="discount_type")
    )
    discount_value: Mapped[int] = mapped_column(Integer)  # درصد یا مبلغ

    min_order_amount: Mapped[int] = mapped_column(BigInteger, default=0)
    max_discount_amount: Mapped[Optional[int]] = mapped_column(BigInteger)

    usage_limit: Mapped[Optional[int]] = mapped_column(Integer)
    usage_limit_per_user: Mapped[int] = mapped_column(Integer, default=1)
    used_count: Mapped[int] = mapped_column(Integer, default=0)

    valid_from: Mapped[datetime] = mapped_column(DateTime, default=utc_now)
    valid_until: Mapped[datetime] = mapped_column(DateTime, default=utc_now)

    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_vip_only: Mapped[bool] = mapped_column(Boolean, default=False)
    first_order_only: Mapped[bool] = mapped_column(Boolean, default=False)

    created_by: Mapped[Optional[str]] = mapped_column(String(64))
    metadata_json: Mapped[Optional[str]] = mapped_column(Text)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, onupdate=utc_now)
    is_deleted: Mapped[bool] = mapped_column(Boolean, default=False)
    deleted_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    usages: Mapped[list["CouponUsage"]] = relationship(
        back_populates="coupon", cascade="all, delete-orphan"
    )


class CouponUsage(Base):
    __tablename__ = "coupon_usages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    coupon_id: Mapped[int] = mapped_column(
        ForeignKey("coupons.id", ondelete="CASCADE"), index=True
    )
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), index=True
    )
    order_id: Mapped[int] = mapped_column(
        ForeignKey("orders.id", ondelete="RESTRICT"), index=True
    )
    discount_amount: Mapped[int] = mapped_column(BigInteger)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)

    coupon: Mapped["Coupon"] = relationship(back_populates="usages")
    user: Mapped["User"] = relationship()


# ============== پرداخت ==============

class Payment(Base):
    __tablename__ = "payments"
    __table_args__ = (
        Index("ix_payments_order", "order_id", "status"),
        Index("ix_payments_user", "user_id", "created_at"),
        Index("ix_payments_txn", "transaction_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    order_id: Mapped[int] = mapped_column(
        ForeignKey("orders.id", ondelete="CASCADE"), index=True
    )
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), index=True
    )

    method: Mapped[PaymentMethod] = mapped_column(
        SAEnum(PaymentMethod, name="payment_method")
    )
    status: Mapped[PaymentStatus] = mapped_column(
        SAEnum(PaymentStatus, name="payment_status"),
        default=PaymentStatus.PENDING,
    )

    amount: Mapped[int] = mapped_column(BigInteger)  # مبلغ - ثابت

    # Online gateway
    transaction_id: Mapped[str] = mapped_column(String(128), index=True)
    reference_id: Mapped[Optional[str]] = mapped_column(String(128))
    gateway: Mapped[Optional[str]] = mapped_column(String(64))
    gateway_response: Mapped[Optional[str]] = mapped_column(Text)
    authority: Mapped[Optional[str]] = mapped_column(String(128))

    # Card-to-card (encrypted)
    card_number_hash: Mapped[Optional[str]] = mapped_column(String(128))
    tracking_code_encrypted: Mapped[Optional[str]] = mapped_column(Text)
    receipt_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("payment_receipts.id", ondelete="SET NULL")
    )

    # Audit
    ip_address: Mapped[Optional[str]] = mapped_column(String(64))
    user_agent: Mapped[Optional[str]] = mapped_column(String(256))

    paid_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    verified_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    verified_by: Mapped[Optional[str]] = mapped_column(String(64))
    verified_by_telegram_id: Mapped[Optional[int]] = mapped_column(BigInteger)

    rejection_reason: Mapped[Optional[str]] = mapped_column(Text)
    rejected_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    invoice_number: Mapped[Optional[str]] = mapped_column(String(64))
    invoice_url: Mapped[Optional[str]] = mapped_column(String(512))

    notes: Mapped[Optional[str]] = mapped_column(Text)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, onupdate=utc_now)
    is_deleted: Mapped[bool] = mapped_column(Boolean, default=False)
    deleted_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    order: Mapped["Order"] = relationship(back_populates="payments")
    user: Mapped["User"] = relationship()


class PaymentReceipt(Base):
    __tablename__ = "payment_receipts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), index=True
    )
    order_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("orders.id", ondelete="SET NULL"), index=True
    )
    file_path: Mapped[str] = mapped_column(String(512))
    file_id: Mapped[Optional[str]] = mapped_column(String(256))
    file_hash: Mapped[str] = mapped_column(String(128), index=True)
    file_size: Mapped[int] = mapped_column(Integer)
    mime_type: Mapped[str] = mapped_column(String(64))
    amount: Mapped[Optional[int]] = mapped_column(BigInteger)
    tracking_code: Mapped[Optional[str]] = mapped_column(String(64))
    uploaded_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)
    ip_address: Mapped[Optional[str]] = mapped_column(String(64))
    submitted_via: Mapped[str] = mapped_column(String(32), default="telegram")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)


# ============== اطلاع‌رسانی ==============

class Notification(Base):
    __tablename__ = "notifications"
    __table_args__ = (
        Index("ix_notif_user_unread", "user_id", "is_read"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    title: Mapped[str] = mapped_column(String(256))
    message: Mapped[str] = mapped_column(Text)
    notification_type: Mapped[str] = mapped_column(String(32), index=True)

    is_read: Mapped[bool] = mapped_column(Boolean, default=False)
    read_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    related_id: Mapped[Optional[str]] = mapped_column(String(64))
    related_type: Mapped[Optional[str]] = mapped_column(String(32))

    sent_via_telegram: Mapped[bool] = mapped_column(Boolean, default=False)
    telegram_message_id: Mapped[Optional[int]] = mapped_column(Integer)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, index=True)


class BroadcastMessage(Base):
    __tablename__ = "broadcast_messages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    title: Mapped[Optional[str]] = mapped_column(String(256))
    message: Mapped[str] = mapped_column(Text)
    target_type: Mapped[str] = mapped_column(String(32))
    target_filter: Mapped[Optional[str]] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(32), default="draft", index=True)
    scheduled_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    sent_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    recipients_count: Mapped[int] = mapped_column(Integer, default=0)
    delivered_count: Mapped[int] = mapped_column(Integer, default=0)
    failed_count: Mapped[int] = mapped_column(Integer, default=0)
    read_count: Mapped[int] = mapped_column(Integer, default=0)

    created_by: Mapped[Optional[str]] = mapped_column(String(64))
    notes: Mapped[Optional[str]] = mapped_column(Text)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, onupdate=utc_now)


# ============== نشست ادمین ==============

class AdminSession(Base):
    __tablename__ = "admin_sessions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, index=True)
    token: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    ip_address: Mapped[Optional[str]] = mapped_column(String(64))
    user_agent: Mapped[Optional[str]] = mapped_column(String(512))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)
    expires_at: Mapped[datetime] = mapped_column(DateTime, index=True)
    last_used_at: Mapped[Optional[datetime]] = mapped_column(DateTime)


# ============== لاگ ادمین ==============

class AdminLog(Base):
    __tablename__ = "admin_logs"
    __table_args__ = (
        Index("ix_admin_logs_admin_time", "admin_id", "occurred_at"),
        Index("ix_admin_logs_action", "action"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    admin_id: Mapped[str] = mapped_column(String(64))
    admin_username: Mapped[Optional[str]] = mapped_column(String(64))
    admin_telegram_id: Mapped[Optional[int]] = mapped_column(BigInteger)

    action: Mapped[str] = mapped_column(String(64))
    entity_type: Mapped[Optional[str]] = mapped_column(String(64))
    entity_id: Mapped[Optional[str]] = mapped_column(String(64))

    description: Mapped[Optional[str]] = mapped_column(Text)
    before_state: Mapped[Optional[str]] = mapped_column(Text)
    after_state: Mapped[Optional[str]] = mapped_column(Text)
    metadata_json: Mapped[Optional[str]] = mapped_column(Text)

    ip_address: Mapped[Optional[str]] = mapped_column(String(64))
    user_agent: Mapped[Optional[str]] = mapped_column(String(512))
    occurred_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)
