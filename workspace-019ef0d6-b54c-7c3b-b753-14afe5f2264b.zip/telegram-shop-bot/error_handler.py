"""هندلر خطای سراسری - جلوگیری از کرش و نمایش پیام دوستانه"""
import logging
from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message, TelegramObject

import keyboards
import texts


logger = logging.getLogger(__name__)


class ErrorHandlerMiddleware(BaseMiddleware):
    """هندلر خطا - ارسال پیام دوستانه به کاربر و جلوگیری از کرش ربات."""

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        try:
            return await handler(event, data)
        except Exception as exc:
            user_id = getattr(getattr(event, "from_user", None), "id", "unknown")
            logger.exception(
                f"Error handling update from user={user_id}: {exc}"
            )
            # ارسال پیام دوستانه به کاربر
            try:
                if isinstance(event, Message):
                    keyboard = (
                        keyboards.main_menu(user_id) if isinstance(user_id, int) else None
                    )
                    await event.answer(
                        texts.ERR_GENERAL,
                        reply_markup=keyboard,
                    )
                elif isinstance(event, CallbackQuery):
                    await event.answer(texts.ERR_GENERAL, show_alert=True)
            except Exception:
                pass  # اگه حتی ارسال پیام هم شکست خورد، بی‌صدا رد بشو
            return None
