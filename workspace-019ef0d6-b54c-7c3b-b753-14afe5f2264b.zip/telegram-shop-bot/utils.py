"""توابع کمکی - عمومی"""
import hashlib
import re
import secrets
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import config


# ============== اعداد فارسی ==============

def fa(value) -> str:
    """تبدیل اعداد به فارسی."""
    en = "0123456789"
    fa_digits = "۰۱۲۳۴۵۶۷۸۹"
    return str(value).translate(str.maketrans(en, fa_digits))


def en(value: str) -> str:
    """تبدیل اعداد فارسی/عربی به انگلیسی."""
    fa_chars = "۰۱۲۳۴۵۶۷۸۹"
    ar_chars = "٠١٢٣٤٥٦٧٨٩"
    en_chars = "0123456789"
    table = str.maketrans(fa_chars + ar_chars, en_chars * 2)
    return str(value).translate(table)


def fmt_toman(amount: int) -> str:
    """قالب‌بندی مبلغ تومان."""
    return fa(f"{amount:,}")


# ============== تاریخ ==============

def fmt_date(dt: Optional[datetime]) -> str:
    """قالب‌بندی تاریخ به فارسی."""
    if dt is None:
        return "—"
    # تبدیل به UTC
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    local_dt = dt.astimezone(timezone.utc)
    return local_dt.strftime("%Y/%m/%d %H:%M")


# ============== تولید شناسه ==============

def gen_order_number() -> str:
    """تولید شماره سفارش یکتا."""
    return f"ORD-{datetime.now().strftime('%y%m%d')}-{secrets.token_hex(3).upper()}"


def gen_coupon_code(length: int = 8) -> str:
    """تولید کد تخفیف تصادفی."""
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return "".join(secrets.choice(alphabet) for _ in range(length))


def gen_token(length: int = 32) -> str:
    """تولید توکن امن."""
    return secrets.token_urlsafe(length)


# ============== رمز عبور ==============

def hash_password(password: str) -> str:
    """هش کردن رمز عبور با bcrypt."""
    import bcrypt
    rounds = config.BCRYPT_ROUNDS
    salt = bcrypt.gensalt(rounds=rounds)
    return bcrypt.hashpw(password.encode(), salt).decode()


def verify_password(password: str, hashed: str) -> bool:
    """بررسی رمز عبور."""
    import bcrypt
    try:
        return bcrypt.checkpw(password.encode(), hashed.encode())
    except Exception:
        return False


# ============== رمزنگاری ==============

def encrypt(text: str) -> str:
    """رمزنگاری ساده با XOR + base64."""
    import base64

    key = config.ENCRYPTION_KEY.encode() if config.ENCRYPTION_KEY else b"default-key"
    text_bytes = text.encode()
    encrypted = bytes([b ^ key[i % len(key)] for i, b in enumerate(text_bytes)])
    return base64.b64encode(encrypted).decode()


def decrypt(ciphertext: str) -> str:
    """رمزگشایی."""
    import base64

    if not ciphertext:
        return ""
    try:
        key = config.ENCRYPTION_KEY.encode() if config.ENCRYPTION_KEY else b"default-key"
        encrypted = base64.b64decode(ciphertext.encode())
        decrypted = bytes([b ^ key[i % len(key)] for i, b in enumerate(encrypted)])
        return decrypted.decode()
    except Exception:
        return ""


# ============== هش فایل ==============

def file_hash(data: bytes) -> str:
    """تولید هش SHA-256 برای فایل."""
    return hashlib.sha256(data).hexdigest()


# ============== اعتبارسنجی ==============

PHONE_RE = re.compile(r"^[\d۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩]\d{9,14}$")


def is_valid_phone(text: str) -> bool:
    """بررسی شماره تلفن."""
    cleaned = en(text).strip()
    return bool(PHONE_RE.match(cleaned))


def normalize_phone(text: str) -> str:
    """نرمال‌سازی شماره تلفن."""
    cleaned = en(text).strip().replace(" ", "").replace("-", "")
    if cleaned.startswith("0098"):
        cleaned = "+98" + cleaned[4:]
    elif cleaned.startswith("0"):
        cleaned = "+98" + cleaned[1:]
    elif not cleaned.startswith("+98") and not cleaned.startswith("98"):
        cleaned = "+98" + cleaned
    return cleaned


# ============== رد شدن از مرحله اختیاری ==============

SKIP_WORDS = {"-", "ردشدن", "رد شدن", "skip", "بیخیال", "ندارد", "no", "none", "خالی"}


def is_skip(text) -> bool:
    """بررسی می‌کند که آیا کاربر می‌خواهد از مرحله اختیاری رد شود."""
    if text is None:
        return False
    cleaned = str(text).strip().lower()
    return cleaned in {w.lower() for w in SKIP_WORDS}


def get_text(message) -> str:
    """استخراج متن از پیام - اگر پیام متن نداشته باشد، رشته خالی برمی‌گرداند."""
    return message.text.strip() if message.text else ""


# ============== نام فایل امن ==============

def safe_filename(name: str) -> str:
    """ساخت نام فایل امن."""
    return re.sub(r"[^\w\-\.]", "_", name)
