"""سرویس سفارش - با وضعیت‌های جدید و محاسبه صحیح آمار فروش

نکات مهم:
- مبلغ total_amount هرگز تغییر نمی‌کند بعد از ایجاد سفارش
- تمام تغییرات وضعیت در تاریخچه ثبت می‌شود
- آمار فروش از روی total_amount محاسبه می‌شود (نه از روی وضعیت فعلی)
"""
import json
import logging
from datetime import datetime, timedelta, timezone
from typing import Optional, Sequence

from sqlalchemy import func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from database import get_session
from models import (
    Order,
    OrderItem,
    OrderStatus,
    OrderStatusHistory,
    Product,
    User,
    ACTIVE_ORDER_STATUSES,
    ARCHIVED_ORDER_STATUSES,
    SALES_COUNTED_STATUSES,
)


logger = logging.getLogger(__name__)


class OrderService:
    """سرویس سفارش."""

    @staticmethod
    async def create_order(
        user: User,
        *,
        shipping_name: str,
        shipping_phone: str,
        shipping_province: str,
        shipping_city: str,
        shipping_address: str,
        shipping_postal_code: str,
        cart_items: list[tuple[Product, int]],
        coupon_code: Optional[str] = None,
        coupon_discount: int = 0,
        payment_method: str = "card_to_card",
        tracking_code: Optional[str] = None,
        receipt_file_id: Optional[str] = None,
        ip_address: Optional[str] = None,
        customer_notes: Optional[str] = None,
    ) -> tuple[Optional[Order], list[str]]:
        """ساخت سفارش جدید.

        نکته مهم: total_amount هرگز تغییر نمی‌کند.
        """
        from utils import gen_order_number

        if not cart_items:
            return None, ["سبد خرید خالی است"]

        # محاسبه subtotal از اقلام
        subtotal = 0
        order_items_data = []
        for product, qty in cart_items:
            price = product.effective_price
            item_total = price * qty
            subtotal += item_total
            order_items_data.append({
                "product_id": product.id,
                "product_name": product.name,
                "product_sku": product.sku,
                "product_image_url": (
                    product.image_url if hasattr(product, "image_url") else None
                ),
                "quantity": qty,
                "unit_price": price,
                "total_price": item_total,
            })

        discount = max(0, coupon_discount)
        shipping_cost = 0 if subtotal >= 500_000 else 30_000
        tax_amount = int((subtotal - discount) * 0.09)
        total_amount = subtotal - discount + shipping_cost + tax_amount
        total_amount = max(0, total_amount)

        async with get_session() as session:
            order = Order(
                order_number=gen_order_number(),
                user_id=user.id,
                status=OrderStatus.PENDING_PAYMENT.value,
                subtotal=subtotal,
                discount_amount=discount,
                shipping_cost=shipping_cost,
                tax_amount=tax_amount,
                total_amount=total_amount,
                final_amount=total_amount,
                coupon_code=coupon_code,
                payment_method=payment_method,
                tracking_code=tracking_code,
                receipt_file_id=receipt_file_id,
                shipping_name=shipping_name,
                shipping_phone=shipping_phone,
                shipping_province=shipping_province,
                shipping_city=shipping_city,
                shipping_address=shipping_address,
                shipping_postal_code=shipping_postal_code,
                customer_notes=customer_notes,
                ip_address=ip_address,
                paid_at=None,  # تایید نشده
            )
            session.add(order)
            await session.flush()

            # اقلام سفارش
            for item_data in order_items_data:
                oi = OrderItem(**item_data, order_id=order.id)
                session.add(oi)

            # تاریخچه وضعیت
            history = OrderStatusHistory(
                order_id=order.id,
                from_status=None,
                to_status=OrderStatus.PENDING_PAYMENT.value,
                changed_by_telegram_id=user.telegram_id,
                changed_by=str(user.telegram_id),
                reason="Order created",
            )
            session.add(history)

            # بروزرسانی کاربر
            user.orders_count += 1
            user.last_activity_at = datetime.now(timezone.utc)

            await session.flush()
            await session.refresh(order)
            order_id = order.id
            order_num = order.order_number

        logger.info(f"Order created: {order_num} total={total_amount} user={user.telegram_id}")
        return order, []

    @staticmethod
    async def change_status(
        order_id: int,
        new_status: str,
        *,
        changed_by: Optional[str] = None,
        changed_by_telegram_id: Optional[int] = None,
        reason: Optional[str] = None,
        note: Optional[str] = None,
    ) -> Optional[Order]:
        """تغییر وضعیت سفارش با ثبت در تاریخچه.

        نکته مهم: total_amount هرگز تغییر نمی‌کند.
        فقط status و timestamps (paid_at, shipped_at, ...) تغییر می‌کنند.
        """
        if new_status not in [s.value for s in OrderStatus]:
            logger.error(f"Invalid status: {new_status}")
            return None

        async with get_session() as session:
            order = await session.get(Order, order_id)
            if not order:
                return None

            old_status = order.status

            # اگر وضعیت تغییر نکرده، کاری نکن
            if old_status == new_status:
                return order

            # به‌روزرسانی فیلد status و timestamps مربوطه
            now = datetime.now(timezone.utc)
            updates = {"status": new_status, "updated_at": now}

            # تنظیم timestamp مربوط به هر وضعیت
            if new_status == OrderStatus.PAID.value and not order.paid_at:
                updates["paid_at"] = now
            elif new_status == OrderStatus.SHIPPED.value and not order.shipped_at:
                updates["shipped_at"] = now
            elif new_status == OrderStatus.COMPLETED.value and not order.completed_at:
                updates["completed_at"] = now
            elif new_status == OrderStatus.CANCELLED.value and not order.cancelled_at:
                updates["cancelled_at"] = now

            # اعمال تغییرات
            await session.execute(
                update(Order)
                .where(Order.id == order_id)
                .values(**updates)
            )

            # بازگشت موجودی در صورت لغو
            if new_status == OrderStatus.CANCELLED.value and old_status not in (
                OrderStatus.CANCELLED.value,
                OrderStatus.COMPLETED.value,
            ):
                # فقط اگر قبلاً لغو نشده بود
                result = await session.execute(
                    select(OrderItem).where(OrderItem.order_id == order_id)
                )
                items = result.scalars().all()
                for item in items:
                    product = await session.get(Product, item.product_id)
                    if product:
                        product.stock += item.quantity
                        product.purchase_count = max(0, product.purchase_count - item.quantity)

            # ثبت در تاریخچه
            history = OrderStatusHistory(
                order_id=order_id,
                from_status=old_status,
                to_status=new_status,
                changed_by=changed_by,
                changed_by_telegram_id=changed_by_telegram_id,
                reason=reason,
                note=note,
                changed_at=now,
            )
            session.add(history)

            await session.flush()
            await session.refresh(order)

            logger.info(
                f"Order {order.order_number}: {old_status} -> {new_status} "
                f"(total stays: {order.total_amount:,})"
            )
            return order

    @staticmethod
    async def get_order(order_id: int) -> Optional[Order]:
        """دریافت سفارش با اقلام و وضعیت."""
        async with get_session() as session:
            return await session.get(Order, order_id)

    @staticmethod
    async def get_by_number(order_number: str) -> Optional[Order]:
        async with get_session() as session:
            result = await session.execute(
                select(Order).where(Order.order_number == order_number)
            )
            return result.scalar_one_or_none()

    @staticmethod
    async def list_for_user(
        user_id: int,
        *,
        page: int = 1,
        page_size: int = 20,
    ) -> Sequence[Order]:
        """سفارشات یک کاربر."""
        async with get_session() as session:
            result = await session.execute(
                select(Order)
                .where(Order.user_id == user_id, Order.is_deleted == False)
                .order_by(Order.created_at.desc())
                .offset((page - 1) * page_size)
                .limit(page_size)
            )
            return list(result.scalars().all())

    @staticmethod
    async def list_active_orders(
        *, page: int = 1, page_size: int = 30
    ) -> Sequence[Order]:
        """سفارشات فعال (نیاز به اقدام)."""
        async with get_session() as session:
            result = await session.execute(
                select(Order)
                .where(
                    Order.status.in_(ACTIVE_ORDER_STATUSES),
                    Order.is_deleted == False,
                )
                .order_by(Order.created_at.asc())
                .offset((page - 1) * page_size)
                .limit(page_size)
            )
            return list(result.scalars().all())

    @staticmethod
    async def list_archived_orders(
        *, page: int = 1, page_size: int = 30
    ) -> Sequence[Order]:
        """سفارشات آرشیو شده (تکمیل، ارسال، لغو)."""
        async with get_session() as session:
            result = await session.execute(
                select(Order)
                .where(
                    Order.status.in_(ARCHIVED_ORDER_STATUSES),
                    Order.is_deleted == False,
                )
                .order_by(Order.updated_at.desc())
                .offset((page - 1) * page_size)
                .limit(page_size)
            )
            return list(result.scalars().all())

    @staticmethod
    async def list_items(order_id: int) -> Sequence[OrderItem]:
        async with get_session() as session:
            result = await session.execute(
                select(OrderItem).where(OrderItem.order_id == order_id)
            )
            return list(result.scalars().all())

    @staticmethod
    async def get_status_history(order_id: int) -> Sequence[OrderStatusHistory]:
        async with get_session() as session:
            result = await session.execute(
                select(OrderStatusHistory)
                .where(OrderStatusHistory.order_id == order_id)
                .order_by(OrderStatusHistory.changed_at)
            )
            return list(result.scalars().all())

    # ============== آمار فروش ==============

    @staticmethod
    async def get_sales_stats() -> dict:
        """دریافت آمار کلی فروش.

        محاسبه از total_amount که هرگز تغییر نمی‌کند.
        فقط سفارشات لغو شده از آمار حذف می‌شوند.
        """
        async with get_session() as session:
            today_start = datetime.now(timezone.utc).replace(
                hour=0, minute=0, second=0, microsecond=0
            )
            week_start = today_start - timedelta(days=today_start.weekday())
            month_start = today_start.replace(day=1)

            # تعداد کل سفارشات (غیر لغو)
            total_orders = (await session.execute(
                select(func.count(Order.id)).where(
                    Order.status != OrderStatus.CANCELLED.value,
                    Order.is_deleted == False,
                )
            )).scalar() or 0

            # تعداد سفارشات در انتظار
            pending_orders = (await session.execute(
                select(func.count(Order.id)).where(
                    Order.status == OrderStatus.PENDING_PAYMENT.value,
                    Order.is_deleted == False,
                )
            )).scalar() or 0

            # درآمد کل (بدون لغوها)
            total_revenue = (await session.execute(
                select(func.coalesce(func.sum(Order.total_amount), 0)).where(
                    Order.status != OrderStatus.CANCELLED.value,
                    Order.is_deleted == False,
                )
            )).scalar() or 0

            # درآمد امروز
            today_revenue = (await session.execute(
                select(func.coalesce(func.sum(Order.total_amount), 0)).where(
                    Order.status != OrderStatus.CANCELLED.value,
                    Order.paid_at >= today_start,
                    Order.is_deleted == False,
                )
            )).scalar() or 0

            # درآمد هفته
            week_revenue = (await session.execute(
                select(func.coalesce(func.sum(Order.total_amount), 0)).where(
                    Order.status != OrderStatus.CANCELLED.value,
                    Order.paid_at >= week_start,
                    Order.is_deleted == False,
                )
            )).scalar() or 0

            # درآمد ماه
            month_revenue = (await session.execute(
                select(func.coalesce(func.sum(Order.total_amount), 0)).where(
                    Order.status != OrderStatus.CANCELLED.value,
                    Order.paid_at >= month_start,
                    Order.is_deleted == False,
                )
            )).scalar() or 0

            return {
                "total_orders": total_orders,
                "pending_orders": pending_orders,
                "total_revenue": int(total_revenue),
                "today_revenue": int(today_revenue),
                "week_revenue": int(week_revenue),
                "month_revenue": int(month_revenue),
            }

    @staticmethod
    async def daily_sales(target_date: Optional[datetime] = None) -> tuple[int, int]:
        """فروش روزانه (تعداد، مبلغ)."""
        target = target_date or datetime.now(timezone.utc)
        day_start = target.replace(hour=0, minute=0, second=0, microsecond=0)
        day_end = day_start + timedelta(days=1)
        async with get_session() as session:
            count = (await session.execute(
                select(func.count(Order.id)).where(
                    Order.status != OrderStatus.CANCELLED.value,
                    Order.paid_at >= day_start,
                    Order.paid_at < day_end,
                    Order.is_deleted == False,
                )
            )).scalar() or 0
            total = (await session.execute(
                select(func.coalesce(func.sum(Order.total_amount), 0)).where(
                    Order.status != OrderStatus.CANCELLED.value,
                    Order.paid_at >= day_start,
                    Order.paid_at < day_end,
                    Order.is_deleted == False,
                )
            )).scalar() or 0
            return int(count), int(total)

    @staticmethod
    async def cancel_order(
        order_id: int,
        *,
        reason: Optional[str] = None,
        changed_by: Optional[str] = None,
        changed_by_telegram_id: Optional[int] = None,
    ) -> Optional[Order]:
        """لغو سفارش با بازگشت موجودی و ثبت در تاریخچه."""
        return await OrderService.change_status(
            order_id,
            OrderStatus.CANCELLED.value,
            changed_by=changed_by,
            changed_by_telegram_id=changed_by_telegram_id,
            reason=reason or "Cancelled by admin",
        )

    @staticmethod
    async def approve_payment(
        order_id: int,
        *,
        changed_by: Optional[str] = None,
        changed_by_telegram_id: Optional[int] = None,
    ) -> Optional[Order]:
        """تایید پرداخت و تغییر وضعیت به paid."""
        return await OrderService.change_status(
            order_id,
            OrderStatus.PAID.value,
            changed_by=changed_by,
            changed_by_telegram_id=changed_by_telegram_id,
            reason="Payment approved",
        )

    @staticmethod
    async def mark_processing(
        order_id: int,
        *,
        changed_by: Optional[str] = None,
        changed_by_telegram_id: Optional[int] = None,
    ) -> Optional[Order]:
        """تغییر وضعیت به در حال پردازش."""
        return await OrderService.change_status(
            order_id, OrderStatus.PROCESSING.value,
            changed_by=changed_by,
            changed_by_telegram_id=changed_by_telegram_id,
        )

    @staticmethod
    async def mark_ready_to_ship(
        order_id: int,
        *,
        changed_by: Optional[str] = None,
        changed_by_telegram_id: Optional[int] = None,
    ) -> Optional[Order]:
        """تغییر وضعیت به آماده ارسال."""
        return await OrderService.change_status(
            order_id, OrderStatus.READY_TO_SHIP.value,
            changed_by=changed_by,
            changed_by_telegram_id=changed_by_telegram_id,
        )

    @staticmethod
    async def mark_shipped(
        order_id: int,
        *,
        tracking_code: Optional[str] = None,
        carrier: Optional[str] = None,
        changed_by: Optional[str] = None,
        changed_by_telegram_id: Optional[int] = None,
    ) -> Optional[Order]:
        """تغییر وضعیت به ارسال شده."""
        async with get_session() as session:
            order = await session.get(Order, order_id)
            if order and tracking_code:
                await session.execute(
                    update(Order)
                    .where(Order.id == order_id)
                    .values(tracking_code=tracking_code, carrier=carrier)
                )
        return await OrderService.change_status(
            order_id, OrderStatus.SHIPPED.value,
            changed_by=changed_by,
            changed_by_telegram_id=changed_by_telegram_id,
            reason=f"Shipped via {carrier}" if carrier else "Shipped",
        )

    @staticmethod
    async def mark_completed(
        order_id: int,
        *,
        changed_by: Optional[str] = None,
        changed_by_telegram_id: Optional[int] = None,
    ) -> Optional[Order]:
        """تغییر وضعیت به تکمیل شده."""
        return await OrderService.change_status(
            order_id, OrderStatus.COMPLETED.value,
            changed_by=changed_by,
            changed_by_telegram_id=changed_by_telegram_id,
            reason="Order completed",
        )
