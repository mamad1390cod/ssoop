"""Migration script - اضافه کردن ستون‌های جدید بدون حذف داده‌ها

این اسکریپت ستون‌های جدیدی که در schema جدید اضافه شده‌اند
را به دیتابیس موجود اضافه می‌کند، بدون از دست رفتن داده‌ها.
"""
import asyncio
import logging
import os
import sqlite3
from pathlib import Path

import config


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ============== لیست ستون‌هایی که باید اضافه شوند ==============

# هر آیتم: (table_name, column_name, column_definition_sql)
# این لیست شامل تمام ستون‌های جدیدی است که در مدل‌های جدید اضافه شده

COLUMNS_TO_ADD = [
    # users - ستون‌های جدید برای پروفایل
    ("users", "first_name", "VARCHAR(128)"),
    ("users", "last_name", "VARCHAR(128)"),
    ("users", "email", "VARCHAR(128)"),
    ("users", "language_code", "VARCHAR(8) DEFAULT 'fa'"),
    ("users", "loyalty_points", "INTEGER DEFAULT 0"),
    ("users", "is_verified", "BOOLEAN DEFAULT 0"),
    ("users", "last_activity_at", "DATETIME"),
    ("users", "metadata_json", "TEXT"),

    # categories - ستون slug
    ("categories", "slug", "VARCHAR(128)"),
    ("categories", "description", "TEXT"),
    ("categories", "image_url", "VARCHAR(512)"),
    ("categories", "parent_id", "INTEGER"),
    ("categories", "updated_at", "DATETIME"),

    # products - ستون‌های جدید
    ("products", "short_description", "VARCHAR(512)"),
    ("products", "cost_price", "BIGINT"),
    ("products", "low_stock_threshold", "INTEGER DEFAULT 5"),
    ("products", "track_inventory", "BOOLEAN DEFAULT 1"),
    ("products", "is_new", "BOOLEAN DEFAULT 1"),
    ("products", "is_vip_only", "BOOLEAN DEFAULT 0"),
    ("products", "view_count", "INTEGER DEFAULT 0"),
    ("products", "purchase_count", "INTEGER DEFAULT 0"),
    ("products", "rating", "FLOAT DEFAULT 0"),
    ("products", "reviews_count", "INTEGER DEFAULT 0"),
    ("products", "images_json", "TEXT"),
    ("products", "weight_grams", "INTEGER"),
    ("products", "dimensions", "VARCHAR(64)"),
    ("products", "tags", "VARCHAR(512)"),
    ("products", "discount_percent", "INTEGER"),
    ("products", "discount_starts_at", "DATETIME"),
    ("products", "discount_ends_at", "DATETIME"),
    ("products", "meta_title", "VARCHAR(256)"),
    ("products", "meta_description", "TEXT"),

    # orders - ستون‌های جدید
    ("orders", "subtotal", "BIGINT DEFAULT 0"),
    ("orders", "discount_amount", "BIGINT DEFAULT 0"),
    ("orders", "shipping_cost", "BIGINT DEFAULT 0"),
    ("orders", "tax_amount", "BIGINT DEFAULT 0"),
    ("orders", "final_amount", "BIGINT DEFAULT 0"),
    ("orders", "coupon_id", "INTEGER"),
    ("orders", "coupon_code", "VARCHAR(32)"),
    ("orders", "shipping_province", "VARCHAR(64) DEFAULT ''"),
    ("orders", "shipping_city", "VARCHAR(64) DEFAULT ''"),
    ("orders", "shipping_postal_code", "VARCHAR(20) DEFAULT ''"),
    ("orders", "payment_method", "VARCHAR(32)"),
    ("orders", "tracking_code", "VARCHAR(64)"),
    ("orders", "shipped_at", "DATETIME"),
    ("orders", "delivered_at", "DATETIME"),
    ("orders", "completed_at", "DATETIME"),
    ("orders", "cancelled_at", "DATETIME"),
    ("orders", "paid_at", "DATETIME"),
    ("orders", "customer_notes", "TEXT"),
    ("orders", "admin_notes", "TEXT"),
    ("orders", "cancel_reason", "TEXT"),
    ("orders", "metadata_json", "TEXT"),
    ("orders", "ip_address", "VARCHAR(64)"),
    ("orders", "user_agent", "VARCHAR(256)"),
    ("orders", "updated_at", "DATETIME"),

    # order_items - ستون‌های جدید
    ("order_items", "product_sku", "VARCHAR(64) DEFAULT ''"),
    ("order_items", "product_image_url", "VARCHAR(512)"),

    # payments - ستون‌های جدید
    ("payments", "reference_id", "VARCHAR(128)"),
    ("payments", "gateway", "VARCHAR(64)"),
    ("payments", "gateway_response", "TEXT"),
    ("payments", "authority", "VARCHAR(128)"),
    ("payments", "card_number_hash", "VARCHAR(128)"),
    ("payments", "tracking_code_encrypted", "TEXT"),
    ("payments", "receipt_id", "INTEGER"),
    ("payments", "ip_address", "VARCHAR(64)"),
    ("payments", "user_agent", "VARCHAR(256)"),
    ("payments", "verified_at", "DATETIME"),
    ("payments", "verified_by", "VARCHAR(64)"),
    ("payments", "verified_by_telegram_id", "BIGINT"),
    ("payments", "rejection_reason", "TEXT"),
    ("payments", "rejected_at", "DATETIME"),
    ("payments", "invoice_number", "VARCHAR(64)"),
    ("payments", "invoice_url", "VARCHAR(512)"),
    ("payments", "notes", "TEXT"),
    ("payments", "updated_at", "DATETIME"),

    # payment_receipts
    ("payment_receipts", "receipt_file_id", "VARCHAR(256)"),
    ("payment_receipts", "amount", "BIGINT"),
    ("payment_receipts", "tracking_code", "VARCHAR(64)"),
    ("payment_receipts", "uploaded_at", "DATETIME"),
    ("payment_receipts", "ip_address", "VARCHAR(64)"),
    ("payment_receipts", "submitted_via", "VARCHAR(32) DEFAULT 'telegram'"),

    # coupons - ستون‌های جدید
    ("coupons", "name", "VARCHAR(128) DEFAULT ''"),
    ("coupons", "description", "TEXT"),
    ("coupons", "min_order_amount", "BIGINT DEFAULT 0"),
    ("coupons", "max_discount_amount", "BIGINT"),
    ("coupons", "usage_limit", "INTEGER"),
    ("coupons", "usage_limit_per_user", "INTEGER DEFAULT 1"),
    ("coupons", "valid_from", "DATETIME"),
    ("coupons", "valid_until", "DATETIME"),
    ("coupons", "is_vip_only", "BOOLEAN DEFAULT 0"),
    ("coupons", "first_order_only", "BOOLEAN DEFAULT 0"),
    ("coupons", "created_by", "VARCHAR(64)"),
    ("coupons", "metadata_json", "TEXT"),
    ("coupons", "updated_at", "DATETIME"),

    # coupon_usages
    ("coupon_usages", "discount_amount", "BIGINT DEFAULT 0"),

    # notifications - ستون‌های جدید
    ("notifications", "notification_type", "VARCHAR(32) DEFAULT 'general'"),
    ("notifications", "is_read", "BOOLEAN DEFAULT 0"),
    ("notifications", "read_at", "DATETIME"),
    ("notifications", "related_id", "VARCHAR(64)"),
    ("notifications", "related_type", "VARCHAR(32)"),
    ("notifications", "sent_via_telegram", "BOOLEAN DEFAULT 0"),
    ("notifications", "telegram_message_id", "INTEGER"),

    # broadcast_messages
    ("broadcast_messages", "title", "VARCHAR(256)"),
    ("broadcast_messages", "target_type", "VARCHAR(32) DEFAULT 'all'"),
    ("broadcast_messages", "target_filter", "TEXT"),
    ("broadcast_messages", "scheduled_at", "DATETIME"),
    ("broadcast_messages", "sent_at", "DATETIME"),
    ("broadcast_messages", "recipients_count", "INTEGER DEFAULT 0"),
    ("broadcast_messages", "delivered_count", "INTEGER DEFAULT 0"),
    ("broadcast_messages", "failed_count", "INTEGER DEFAULT 0"),
    ("broadcast_messages", "read_count", "INTEGER DEFAULT 0"),
    ("broadcast_messages", "created_by", "VARCHAR(64)"),
    ("broadcast_messages", "notes", "TEXT"),
    ("broadcast_messages", "updated_at", "DATETIME"),

    # admin_sessions - ستون‌های جدید
    ("admin_sessions", "ip_address", "VARCHAR(64)"),
    ("admin_sessions", "user_agent", "VARCHAR(512)"),
    ("admin_sessions", "last_used_at", "DATETIME"),

    # admin_logs - ستون‌های جدید
    ("admin_logs", "admin_username", "VARCHAR(64)"),
    ("admin_logs", "admin_telegram_id", "BIGINT"),
    ("admin_logs", "entity_type", "VARCHAR(64)"),
    ("admin_logs", "entity_id", "VARCHAR(64)"),
    ("admin_logs", "description", "TEXT"),
    ("admin_logs", "before_state", "TEXT"),
    ("admin_logs", "after_state", "TEXT"),
    ("admin_logs", "metadata_json", "TEXT"),
    ("admin_logs", "ip_address", "VARCHAR(64)"),
    ("admin_logs", "user_agent", "VARCHAR(512)"),
]


# جداول کاملاً جدید که باید ساخته شوند
NEW_TABLES = [
    # cart_items - کاملاً جدید
    """CREATE TABLE IF NOT EXISTS cart_items (
        id INTEGER PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
        quantity INTEGER DEFAULT 1,
        price_snapshot BIGINT DEFAULT 0,
        created_at DATETIME,
        updated_at DATETIME,
        UNIQUE(user_id, product_id)
    )""",
    """CREATE INDEX IF NOT EXISTS ix_cart_items_user_id ON cart_items(user_id)""",
    """CREATE INDEX IF NOT EXISTS ix_cart_items_product_id ON cart_items(product_id)""",
]


def get_db_path() -> str:
    """دریافت مسیر فایل دیتابیس."""
    if config.DATABASE_TYPE != "sqlite":
        return None
    # استخراج مسیر از DATABASE_URL
    url = config.DATABASE_URL
    if url.startswith("sqlite:///"):
        return url.replace("sqlite:///", "", 1)
    elif url.startswith("sqlite://"):
        return url.replace("sqlite://", "", 1)
    return None


def get_existing_columns(conn, table_name: str) -> set:
    """دریافت ستون‌های موجود در یک جدول."""
    cursor = conn.execute(f"PRAGMA table_info({table_name})")
    return {row[1] for row in cursor.fetchall()}


def table_exists(conn, table_name: str) -> bool:
    """بررسی وجود جدول."""
    cursor = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
        (table_name,),
    )
    return cursor.fetchone() is not None


def migrate():
    """اجرای migration."""
    db_path = get_db_path()

    if db_path is None:
        print("⚠️ این migration فقط برای SQLite کار می‌کند.")
        print("برای MySQL باید از Alembic استفاده کنید:")
        print("  alembic upgrade head")
        return

    if not os.path.exists(db_path):
        print(f"⚠️ فایل دیتابیس {db_path} وجود ندارد.")
        print("برای اولین اجرا فقط کافیست python main.py را اجرا کنید.")
        return

    print(f"📂 دیتابیس: {db_path}")
    print(f"📊 حجم فایل: {os.path.getsize(db_path) / 1024:.1f} KB")

    # پشتیبان‌گیری خودکار قبل از تغییر
    import shutil
    import datetime as dt

    backup_path = f"{db_path}.backup.{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}"
    shutil.copy2(db_path, backup_path)
    print(f"💾 بکاپ ایجاد شد: {backup_path}")

    conn = sqlite3.connect(db_path)
    added_columns = 0
    skipped_columns = 0
    created_tables = 0

    try:
        # ۱. ایجاد جداول جدید
        print("\n📋 ساخت جداول جدید...")
        for create_sql in NEW_TABLES:
            try:
                conn.execute(create_sql)
                conn.commit()
                created_tables += 1
            except Exception as e:
                print(f"  ⚠️ خطا در ساخت: {e}")

        # ۲. اضافه کردن ستون‌های جدید
        print("\n🔧 اضافه کردن ستون‌های جدید...")
        for table_name, column_name, column_def in COLUMNS_TO_ADD:
            if not table_exists(conn, table_name):
                continue  # جدول وجود نداره، بعداً ساخته می‌شود

            existing = get_existing_columns(conn, table_name)
            if column_name in existing:
                skipped_columns += 1
                continue

            try:
                sql = f"ALTER TABLE {table_name} ADD COLUMN {column_name} {column_def}"
                conn.execute(sql)
                conn.commit()
                added_columns += 1
                print(f"  ✅ {table_name}.{column_name}")
            except Exception as e:
                print(f"  ❌ {table_name}.{column_name}: {e}")

        # ۳. مقداردهی اولیه برای ستون‌های ضروری
        print("\n🎯 مقداردهی اولیه...")
        try:
            # orders.subtotal و orders.final_amount اگر خالی هستند با total_amount پر شوند
            if "subtotal" in get_existing_columns(conn, "orders"):
                conn.execute("""
                    UPDATE orders SET subtotal = total_amount WHERE subtotal IS NULL OR subtotal = 0
                """)
            if "final_amount" in get_existing_columns(conn, "orders"):
                conn.execute("""
                    UPDATE orders SET final_amount = total_amount WHERE final_amount IS NULL OR final_amount = 0
                """)
            # order_items.product_sku پر شود - فقط اگر products.sku وجود داره
            if "product_sku" in get_existing_columns(conn, "order_items") and "sku" in get_existing_columns(conn, "products"):
                conn.execute("""
                    UPDATE order_items SET product_sku = (
                        SELECT sku FROM products WHERE products.id = order_items.product_id
                    ) WHERE product_sku = '' OR product_sku IS NULL
                """)
            # admin_sessions.expires_at اگر خالی است
            if "expires_at" in get_existing_columns(conn, "admin_sessions"):
                from datetime import datetime, timedelta, timezone
                conn.execute("""
                    UPDATE admin_sessions SET expires_at = ? WHERE expires_at IS NULL
                """, (datetime.now(timezone.utc) + timedelta(hours=2),))
            conn.commit()
            print("  ✅ مقداردهی اولیه انجام شد")
        except Exception as e:
            print(f"  ⚠️ خطا در مقداردهی (غیرحیاتی): {e}")

    finally:
        conn.close()

    print(f"\n{'='*50}")
    print(f"✅ Migration کامل شد!")
    print(f"  • {added_columns} ستون اضافه شد")
    print(f"  • {skipped_columns} ستون قبلاً وجود داشت")
    print(f"  • {created_tables} جدول جدید ساخته شد")
    print(f"  • بکاپ در: {backup_path}")
    print(f"{'='*50}")


if __name__ == "__main__":
    import config
    migrate()
