"""اتصال و مدیریت دیتابیس - پشتیبانی از SQLite و MySQL"""
from contextlib import asynccontextmanager
from typing import AsyncIterator

from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

import config
from models import Base


def _build_engine_kwargs() -> dict:
    """ساخت پارامترهای engine بر اساس نوع دیتابیس"""
    if config.DATABASE_TYPE == "sqlite":
        return {
            "echo": False,
            # SQLite نیاز به pool ندارد
        }
    else:
        return {
            "echo": False,
            "pool_size": 10,
            "max_overflow": 20,
            "pool_pre_ping": True,
            "pool_recycle": 3600,
        }


# ساخت engine
_engine = create_async_engine(
    config.ASYNC_DATABASE_URL,
    **_build_engine_kwargs(),
)

# ساخت session factory
async_session_factory = async_sessionmaker(
    _engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autoflush=False,
)


async def init_db() -> None:
    """ایجاد تمام جداول"""
    async with _engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def close_db() -> None:
    """بستن اتصال دیتابیس"""
    await _engine.dispose()


@asynccontextmanager
async def get_session() -> AsyncIterator[AsyncSession]:
    """دریافت session به صورت context manager"""
    async with async_session_factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def get_db_session() -> AsyncIterator[AsyncSession]:
    """برای استفاده در handlers - بدون commit خودکار"""
    async with async_session_factory() as session:
        yield session


# اطلاعات دیتابیس
def db_info() -> dict:
    """اطلاعات دیتابیس فعلی"""
    return {
        "type": config.DATABASE_TYPE,
        "url": config.DATABASE_URL,
        "async_url": config.ASYNC_DATABASE_URL,
    }
