"""هندلرهای کاربر - با استفاده از سرویس‌های جدید"""
import json
import logging
from datetime import datetime, timezone
from typing import Optional

from aiogram import F, Router
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

import config
import keyboards
import models
import payments
import texts
import utils
from cart_service import CartService
from database import get_session
from models import Category, Coupon, Order, OrderStatus, Product, User
from order_service import OrderService
from sqlalchemy import select

logger = logging.getLogger(__name__)


# ============== حالت‌ها ==============

class CheckoutStates(StatesGroup):
    name = State()
    phone = State()
    address = State()
    coupon = State()
    payment_method = State()
    receipt = State()
    tracking_code = State()


# ============== Router ==============

user_router = Router(name="user")


# ============== شروع ==============

@user_router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    """/start"""
    await state.clear()
    async with get_session() as session:
        result = await session.execute(
            select(User).where(User.telegram_id == message.from_user.id)
        )
        user = result.scalar_one_or_none()
        if not user:
            user = User(
                telegram_id=message.from_user.id,
                username=message.from_user.username,
                full_name=message.from_user.full_name,
                is_admin=config.is_admin(message.from_user.id),
            )
            session.add(user)
        else:
            if user.username != message.from_user.username:
                user.username = message.from_user.username
            if user.full_name != message.from_user.full_name:
                user.full_name = message.from_user.full_name
        user.last_activity_at = datetime.now(timezone.utc)
    text = (
        f"🌟 سلام {message.from_user.first_name}!\n\n"
        f"به {config.SHOP_NAME} خوش آمدید.\n"
        f"از منوی زیر یکی را انتخاب کنید:"
    )
    await message.answer(text, reply_markup=keyboards.main_menu(message.from_user.id))


# ============== لغو ==============

@user_router.message(F.text == "❌ انصراف")
async def cmd_cancel(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(
        texts.CANCEL,
        reply_markup=keyboards.main_menu(message.from_user.id),
    )


# ============== دکمه‌های بازگشت سراسری ==============

@user_router.callback_query(F.data == "home:main")
async def cb_home(callback: CallbackQuery, state: FSMContext):
    """بازگشت به منوی اصلی."""
    await state.clear()
    try:
        await callback.message.edit_text(
            texts.WELCOME_BACK.format(name=callback.from_user.first_name or ""),
            reply_markup=keyboards.main_menu(callback.from_user.id),
        )
    except Exception:
        await callback.message.answer(
            texts.WELCOME_BACK.format(name=callback.from_user.first_name or ""),
            reply_markup=keyboards.main_menu(callback.from_user.id),
        )
    await callback.answer()


@user_router.callback_query(F.data == "back:cats")
async def cb_back_cats(callback: CallbackQuery):
    """بازگشت به لیست دسته‌ها."""
    async with get_session() as session:
        result = await session.execute(
            select(Category).where(Category.is_active == True, Category.is_deleted == False).order_by(Category.sort_order)
        )
        cats = result.scalars().all()
    await callback.message.edit_text(
        "📂 <b>دسته‌بندی محصولات</b>\n\nیک دسته را انتخاب کنید:",
        reply_markup=keyboards.categories_kb(cats),
    )
    await callback.answer()


@user_router.callback_query(F.data == "show:cart")
async def cb_show_cart(callback: CallbackQuery):
    """نمایش سبد خرید."""
    await callback.message.delete()
    await show_cart_cmd(callback.message)
    await callback.answer()


@user_router.callback_query(F.data == "cancel:action")
async def cb_cancel_action(callback: CallbackQuery, state: FSMContext):
    """لغو عملیات فعلی."""
    await state.clear()
    await callback.message.edit_text(
        texts.CANCEL,
        reply_markup=keyboards.main_menu(callback.from_user.id),
    )
    await callback.answer()


# ============== محصولات ==============

@user_router.message(F.text == "🛍 محصولات")
async def show_categories(message: Message):
    async with get_session() as session:
        result = await session.execute(
            select(Category)
            .where(Category.is_active == True, Category.is_deleted == False)
            .order_by(Category.sort_order, Category.id)
        )
        cats = result.scalars().all()
    if not cats:
        await message.answer(texts.EMPTY_PRODUCTS)
        return
    await message.answer(
        "📂 <b>دسته‌بندی محصولات</b>\n\nیک دسته را انتخاب کنید:",
        reply_markup=keyboards.categories_kb(cats),
    )


@user_router.callback_query(F.data.startswith("cat:"))
async def show_products(callback: CallbackQuery):
    cat_id = int(callback.data.split(":")[1])
    async with get_session() as session:
        result = await session.execute(
            select(Product).where(
                Product.category_id == cat_id,
                Product.is_active == True,
                Product.is_deleted == False,
            )
        )
        products = result.scalars().all()
    if not products:
        await callback.message.edit_text(texts.EMPTY_PRODUCTS)
        await callback.answer()
        return
    await callback.message.edit_text(
        "🛍 <b>محصولات</b>\n\nبرای مشاهده جزئیات کلیک کنید:",
        reply_markup=keyboards.products_kb(products, cat_id),
    )
    await callback.answer()


@user_router.callback_query(F.data.startswith("prod:"))
async def show_product(callback: CallbackQuery):
    pid = int(callback.data.split(":")[1])
    async with get_session() as session:
        product = await session.get(Product, pid)
        if not product or not product.is_active or product.is_deleted:
            await callback.answer("محصول یافت نشد", show_alert=True)
            return
        product.view_count += 1
    cart_items = await CartService.get_cart_with_products(callback.from_user.id)
    qty = 0
    for p, q in cart_items:
        if p.id == pid:
            qty = q
    await callback.message.edit_text(
        texts.product_detail(product, qty),
        reply_markup=keyboards.product_detail_kb(product, qty),
    )
    await callback.answer()


@user_router.callback_query(F.data == "noop")
async def noop(callback: CallbackQuery):
    await callback.answer()


# ============== سبد خرید (DB-backed) ==============

@user_router.callback_query(F.data.startswith("cart:"))
async def update_cart(callback: CallbackQuery):
    parts = callback.data.split(":")
    if len(parts) != 3:
        await callback.answer("خطا", show_alert=True)
        return
    action, pid_str = parts[1], parts[2]
    pid = int(pid_str)
    delta = 1 if action == "+" else -1

    # دریافت تعداد فعلی
    current = 0
    async with get_session() as session:
        # پیدا کردن کاربر
        result = await session.execute(
            select(User).where(User.telegram_id == callback.from_user.id)
        )
        user = result.scalar_one_or_none()
        if not user:
            await callback.answer("خطا", show_alert=True)
            return
        from models import CartItem

        result = await session.execute(
            select(CartItem).where(
                CartItem.user_id == user.id, CartItem.product_id == pid
            )
        )
        item = result.scalar_one_or_none()
        if item:
            current = item.quantity
    new_qty = max(0, current + delta)

    if delta > 0:
        # افزایش
        ok, err = await CartService.add_item(callback.from_user.id, pid, 1)
    else:
        # کاهش
        if new_qty == 0:
            ok = await CartService.remove_item(callback.from_user.id, pid)
            err = "" if ok else "خطا"
        else:
            ok, err = await CartService.update_quantity(callback.from_user.id, pid, new_qty)

    if not ok and err:
        await callback.answer(err, show_alert=True)
        return

    # بارگذاری مجدد نمایش
    async with get_session() as session:
        product = await session.get(Product, pid)
    if product is None:
        await callback.answer("محصول یافت نشد", show_alert=True)
        return

    cart_items = await CartService.get_cart_with_products(callback.from_user.id)
    qty = 0
    for p, q in cart_items:
        if p.id == pid:
            qty = q
    await callback.message.edit_text(
        texts.product_detail(product, qty),
        reply_markup=keyboards.product_detail_kb(product, qty),
    )
    await callback.answer()


@user_router.callback_query(F.data == "cart:clear")
async def cart_clear(callback: CallbackQuery):
    deleted = await CartService.clear_cart(callback.from_user.id)
    text = texts.EMPTY_CART
    if deleted > 0:
        text = f"✅ {utils.fa(deleted)} قلم از سبد حذف شد.\n\n" + texts.EMPTY_CART
    await callback.message.edit_text(
        text,
        reply_markup=keyboards.cart_kb(has_items=False),
    )
    await callback.answer()


@user_router.message(F.text == "🛒 سبد خرید")
async def show_cart_cmd(message: Message):
    items = await CartService.get_cart_with_products(message.from_user.id)
    if not items:
        await message.answer(
            texts.EMPTY_CART,
            reply_markup=keyboards.main_menu(message.from_user.id),
        )
        return
    total = await CartService.cart_total(message.from_user.id)
    await message.answer(
        texts.cart_text(items, total),
        reply_markup=keyboards.cart_kb(has_items=True),
    )


# ============== ثبت سفارش ==============

@user_router.callback_query(F.data == "checkout:start")
async def checkout_start(callback: CallbackQuery, state: FSMContext):
    valid, errors, total, items = await CartService.validate_for_checkout(callback.from_user.id)
    if not valid:
        await callback.answer("\n".join(errors), show_alert=True)
        return
    await state.set_state(CheckoutStates.name)
    await callback.message.edit_text("📝 <b>نام و نام خانوادگی</b> خود را وارد کنید:")
    await callback.answer()


@user_router.message(CheckoutStates.name)
async def checkout_name(message: Message, state: FSMContext):
    name = utils.get_text(message)
    if not name:
        await message.answer("❌ نام نمی‌تواند خالی باشد. دوباره وارد کنید:")
        return
    await state.update_data(name=name)
    await state.set_state(CheckoutStates.phone)
    await message.answer(
        "📞 <b>شماره تماس</b>:",
        reply_markup=keyboards.cancel_kb(),
    )


@user_router.message(CheckoutStates.phone)
async def checkout_phone(message: Message, state: FSMContext):
    phone = utils.get_text(message)
    if not utils.is_valid_phone(phone):
        await message.answer(
            "❌ شماره نامعتبر. دوباره وارد کنید:\n"
            "(مثال: ۰۹۱۲۳۴۵۶۷۸۹ یا +989123456789)"
        )
        return
    normalized = utils.normalize_phone(phone)
    await state.update_data(phone=normalized)

    # ذخیره در پروفایل کاربر
    async with get_session() as session:
        result = await session.execute(
            select(User).where(User.telegram_id == message.from_user.id)
        )
        user = result.scalar_one()
        user.phone = normalized
        sdata = await state.get_data()
        if not user.full_name:
            user.full_name = sdata.get("name")

    await state.set_state(CheckoutStates.address)
    await message.answer(
        "📍 <b>آدرس کامل</b> (استان، شهر، خیابان، پلاک):",
        reply_markup=keyboards.cancel_kb(),
    )


@user_router.message(CheckoutStates.address)
async def checkout_address(message: Message, state: FSMContext):
    address = utils.get_text(message)
    if not address:
        await message.answer("❌ آدرس نمی‌تواند خالی باشد. دوباره وارد کنید:")
        return
    await state.update_data(address=address)
    await state.set_state(CheckoutStates.coupon)
    await message.answer(
        "🎁 <b>کد تخفیف</b> دارید؟\n\n"
        "برای رد شدن یکی از این‌ها را بفرستید:\n"
        "<code>ردشدن</code> یا <code>-</code> یا <code>بیخیال</code>",
        reply_markup=keyboards.cancel_kb(),
    )


@user_router.message(CheckoutStates.coupon)
async def checkout_coupon(message: Message, state: FSMContext):
    text = utils.get_text(message)
    coupon_code = None
    discount = 0

    if utils.is_skip(text):
        coupon_code = None
    elif text:
        # بررسی کد تخفیف
        async with get_session() as session:
            result = await session.execute(
                select(Coupon).where(
                    Coupon.code == text.upper(),
                    Coupon.is_active == True,
                    Coupon.is_deleted == False,
                )
            )
            coupon = result.scalar_one_or_none()
            if coupon:
                now = datetime.now(timezone.utc)
                # بررسی زمان اعتبار
                valid_from = coupon.valid_from
                valid_until = coupon.valid_until
                if valid_from.tzinfo is None:
                    valid_from = valid_from.replace(tzinfo=timezone.utc)
                if valid_until.tzinfo is None:
                    valid_until = valid_until.replace(tzinfo=timezone.utc)
                if valid_from <= now <= valid_until:
                    # بررسی سقف استفاده
                    if coupon.usage_limit is None or coupon.used_count < coupon.usage_limit:
                        coupon_code = coupon.code
                    else:
                        await message.answer("❌ سقف استفاده از کد تخفیف تکمیل شده.")
                else:
                    await message.answer("❌ کد تخفیف منقضی شده.")
            else:
                await message.answer(
                    "❌ کد نامعتبر یا منقضی شده. ادامه می‌دهیم بدون تخفیف..."
                )

    await state.update_data(coupon_code=coupon_code)

    # محاسبه مجموع
    valid, errors, subtotal, items = await CartService.validate_for_checkout(message.from_user.id)
    if not valid:
        await state.clear()
        await message.answer(
            "❌ " + "\n".join(errors),
            reply_markup=keyboards.main_menu(message.from_user.id),
        )
        return

    if coupon_code:
        async with get_session() as session:
            result = await session.execute(
                select(Coupon).where(Coupon.code == coupon_code)
            )
            c = result.scalar_one()
            if c.discount_value <= 100:
                discount = int(subtotal * c.discount_value / 100)
            else:
                discount = c.discount_value
            if c.max_discount_amount is not None:
                discount = min(discount, c.max_discount_amount)

    await state.update_data(subtotal=subtotal, discount=discount)
    await state.set_state(CheckoutStates.payment_method)

    # محاسبه total نهایی
    shipping_cost = 0 if subtotal >= 500_000 else 30_000
    tax_amount = int((subtotal - discount) * 0.09)
    total = max(0, subtotal - discount + shipping_cost + tax_amount)
    await state.update_data(shipping_cost=shipping_cost, tax_amount=tax_amount, total=total)

    text = (
        f"💰 <b>مبلغ قابل پرداخت: {utils.fa(f'{total:,}')} تومان</b>\n\n"
        f"روش پرداخت را انتخاب کنید:"
    )
    await message.answer(
        text,
        reply_markup=keyboards.payment_methods_kb(total),
    )


# ============== پرداخت کارت به کارت ==============

@user_router.callback_query(F.data == "pay:card")
async def pay_card(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    total = data.get("total", 0)
    await state.set_state(CheckoutStates.receipt)
    await callback.message.edit_text(
        texts.card_payment_info(total),
        parse_mode="HTML",
    )
    await callback.answer()
    await callback.message.answer(
        "📸 لطفاً <b>تصویر فیش پرداخت</b> را ارسال کنید:",
    )


@user_router.message(CheckoutStates.receipt, F.photo)
async def receive_receipt(message: Message, state: FSMContext, bot=None):
    """دریافت فیش پرداخت."""
    photo = message.photo[-1]
    file = await bot.get_file(photo.file_id)
    bio = await bot.download_file(file.file_path)
    bio.seek(0)
    file_bytes = bio.read()

    await state.update_data(
        receipt_file_id=photo.file_id,
        receipt_bytes=file_bytes,
        receipt_filename=f"{message.from_user.id}_{photo.file_unique_id}.jpg",
    )
    await state.set_state(CheckoutStates.tracking_code)
    await message.answer(
        "🔢 لطفاً <b>شماره پیگیری تراکنش</b> را وارد کنید:\n\n"
        "(یا <code>ردشدن</code> برای رد شدن)",
        reply_markup=keyboards.cancel_kb(),
    )


@user_router.message(CheckoutStates.receipt)
async def receive_receipt_invalid(message: Message):
    await message.answer(
        "❌ لطفاً فقط <b>تصویر فیش پرداخت</b> را ارسال کنید.",
        parse_mode="HTML",
    )


@user_router.message(CheckoutStates.tracking_code)
async def receive_tracking_code(message: Message, state: FSMContext, bot=None):
    """دریافت شماره پیگیری و ساخت سفارش."""
    sdata = await state.get_data()
    tracking_text = utils.get_text(message)
    tracking_code = "" if utils.is_skip(tracking_text) else tracking_text
    await state.clear()

    # ساخت سفارش با سرویس جدید
    async with get_session() as session:
        result = await session.execute(
            select(User).where(User.telegram_id == message.from_user.id)
        )
        user = result.scalar_one()
        cart_items = await CartService.get_cart_with_products(message.from_user.id)
        if not cart_items:
            await message.answer(
                "❌ سبد خرید خالی شد.",
                reply_markup=keyboards.main_menu(message.from_user.id),
            )
            return

        order, errors = await OrderService.create_order(
            user,
            shipping_name=sdata["name"],
            shipping_phone=sdata["phone"],
            shipping_province="",  # می‌توان بعداً اضافه کرد
            shipping_city="",  # می‌توان بعداً اضافه کرد
            shipping_address=sdata["address"],
            shipping_postal_code="",
            cart_items=cart_items,
            coupon_code=sdata.get("coupon_code"),
            coupon_discount=sdata.get("discount", 0),
            payment_method="card_to_card",
            tracking_code=tracking_code or None,
            receipt_file_id=sdata.get("receipt_file_id"),
            customer_notes=None,
        )

    if order is None:
        await message.answer(
            "❌ خطا در ثبت سفارش:\n" + "\n".join(errors),
            reply_markup=keyboards.main_menu(message.from_user.id),
        )
        return

    # ثبت پرداخت
    payment, err = await payments.submit_card_payment(
        order,
        user,
        file_bytes=sdata.get("receipt_bytes", b""),
        file_name=sdata.get("receipt_filename", "receipt.jpg"),
        mime_type="image/jpeg",
        telegram_file_id=sdata.get("receipt_file_id"),
        tracking_code=tracking_code or None,
    )
    if payment is None:
        await message.answer(f"❌ {err}", parse_mode="HTML")
        return

    # خالی کردن سبد
    await CartService.clear_cart(message.from_user.id)

    # ارسال اعلان به ادمین
    if config.ADMIN_CHAT_ID and bot:
        track_display = tracking_code if tracking_code else "(بدون شماره پیگیری)"
        total_str = utils.fa(f"{order.total_amount:,}")
        admin_text = (
            f"💳 <b>پرداخت جدید</b>\n\n"
            f"🔖 سفارش: <code>{order.order_number}</code>\n"
            f"👤 کاربر: {sdata['name']} ({message.from_user.id})\n"
            f"💰 مبلغ: {total_str} تومان\n"
            f"🔢 پیگیری: <code>{track_display}</code>"
        )
        try:
            if sdata.get("receipt_file_id"):
                await bot.send_photo(
                    config.ADMIN_CHAT_ID,
                    photo=sdata["receipt_file_id"],
                    caption=admin_text,
                    reply_markup=keyboards.admin_approval_kb(order.id),
                )
            else:
                await bot.send_message(
                    config.ADMIN_CHAT_ID,
                    text=admin_text,
                    reply_markup=keyboards.admin_approval_kb(order.id),
                )
        except Exception as e:
            logger.error(f"Admin notify failed: {e}")

    await message.answer(
        texts.PAYMENT_SUBMITTED.format(number=order.order_number),
        reply_markup=keyboards.main_menu(message.from_user.id),
    )


# ============== پرداخت آنلاین ==============

@user_router.callback_query(F.data == "pay:online")
async def pay_online(callback: CallbackQuery, state: FSMContext, bot=None):
    if not config.PAYMENT_MERCHANT_ID:
        await callback.answer("درگاه آنلاین فعال نیست", show_alert=True)
        return
    sdata = await state.get_data()
    await state.clear()

    async with get_session() as session:
        result = await session.execute(
            select(User).where(User.telegram_id == callback.from_user.id)
        )
        user = result.scalar_one()
        cart_items = await CartService.get_cart_with_products(callback.from_user.id)
        if not cart_items:
            await callback.message.edit_text(
                texts.EMPTY_CART,
                reply_markup=keyboards.main_menu(callback.from_user.id),
            )
            return

        order, errors = await OrderService.create_order(
            user,
            shipping_name=sdata["name"],
            shipping_phone=sdata["phone"],
            shipping_province="",
            shipping_city="",
            shipping_address=sdata["address"],
            shipping_postal_code="",
            cart_items=cart_items,
            coupon_code=sdata.get("coupon_code"),
            coupon_discount=sdata.get("discount", 0),
            payment_method="online",
        )
        if order is None:
            await callback.message.edit_text(
                "❌ خطا: " + "\n".join(errors),
            )
            return

    ok, msg, url = await payments.create_online_payment(order)
    await CartService.clear_cart(callback.from_user.id)
    if ok and url:
        await callback.message.edit_text(
            f"💳 برای پرداخت روی لینک کلیک کنید:\n\n🔗 {url}",
            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [InlineKeyboardButton(text="💳 پرداخت", url=url)],
                    [
                        keyboards.back_button("home:main", "🏠 منو"),
                    ],
                ]
            ),
        )
    else:
        await callback.message.edit_text(
            f"❌ خطا: {msg}",
            reply_markup=keyboards.cart_kb(has_items=True),
        )


# ============== سفارش‌های من ==============

@user_router.message(F.text == "📦 سفارش‌های من")
async def my_orders(message: Message):
    async with get_session() as session:
        result = await session.execute(
            select(User).where(User.telegram_id == message.from_user.id)
        )
        user = result.scalar_one_or_none()
        if not user:
            await message.answer("ابتدا /start بزنید.")
            return
        result = await session.execute(
            select(Order)
            .where(Order.user_id == user.id, Order.is_deleted == False)
            .order_by(Order.created_at.desc())
            .limit(20)
        )
        orders = result.scalars().all()
    if not orders:
        await message.answer(texts.ORDER_LIST_EMPTY)
        return

    for o in orders:
        text = texts.order_text(o)
        # اضافه کردن دکمه لغو برای سفارشات فعال
        kb_rows = []
        if o.status in (models.OrderStatus.PENDING_PAYMENT.value, models.OrderStatus.PAID.value):
            kb_rows.append([
                InlineKeyboardButton(
                    text="💳 پرداخت مجدد",
                    callback_data=f"myorder:pay:{o.id}",
                ),
                InlineKeyboardButton(
                    text="❌ لغو",
                    callback_data=f"myorder:cancel:{o.id}",
                ),
            ])
        kb_rows.append([keyboards.back_button("home:main", "🏠 منو")])
        await message.answer(
            text,
            reply_markup=InlineKeyboardMarkup(inline_keyboard=kb_rows),
            parse_mode="HTML",
        )


@user_router.callback_query(F.data.startswith("myorder:cancel:"))
async def cb_myorder_cancel(callback: CallbackQuery):
    """لغو سفارش توسط کاربر."""
    order_id = int(callback.data.split(":")[2])
    async with get_session() as session:
        order = await session.get(Order, order_id)
        if not order or order.user.telegram_id != callback.from_user.id:
            await callback.answer("سفارش یافت نشد", show_alert=True)
            return
        if order.status in (
            models.OrderStatus.SHIPPED.value,
            models.OrderStatus.COMPLETED.value,
            models.OrderStatus.CANCELLED.value,
        ):
            await callback.answer("این سفارش قابل لغو نیست", show_alert=True)
            return

    await OrderService.cancel_order(
        order_id,
        reason="Cancelled by user",
        changed_by=str(callback.from_user.id),
        changed_by_telegram_id=callback.from_user.id,
    )
    await callback.answer("✅ سفارش لغو شد")
    # نمایش وضعیت جدید
    async with get_session() as session:
        order = await session.get(Order, order_id)
    await callback.message.edit_text(
        texts.order_text(order),
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[
                [keyboards.back_button("home:main", "🏠 منو")]
            ]
        ),
    )


@user_router.callback_query(F.data.startswith("myorder:pay:"))
async def cb_myorder_pay(callback: CallbackQuery):
    """پرداخت مجدد سفارش."""
    order_id = int(callback.data.split(":")[2])
    async with get_session() as session:
        order = await session.get(Order, order_id)
        if not order or order.user.telegram_id != callback.from_user.id:
            await callback.answer("سفارش یافت نشد", show_alert=True)
            return
        if order.status != models.OrderStatus.PENDING_PAYMENT.value:
            await callback.answer("این سفارش در انتظار پرداخت نیست", show_alert=True)
            return

    if config.PAYMENT_MERCHANT_ID:
        ok, msg, url = await payments.create_online_payment(order)
        if ok and url:
            await callback.message.edit_text(
                f"💳 برای پرداخت:\n\n🔗 {url}",
                reply_markup=InlineKeyboardMarkup(
                    inline_keyboard=[
                        [InlineKeyboardButton(text="💳 پرداخت", url=url)],
                        [keyboards.back_button("home:main", "🏠 منو")],
                    ]
                ),
            )
        else:
            await callback.answer(f"❌ {msg}", show_alert=True)
    else:
        await callback.message.edit_text(
            texts.card_payment_info(order.total_amount),
            reply_markup=keyboards.card_payment_keyboard(),
        )


# ============== پروفایل ==============

@user_router.message(F.text == "👤 پروفایل")
async def my_profile(message: Message):
    async with get_session() as session:
        result = await session.execute(
            select(User).where(User.telegram_id == message.from_user.id)
        )
        user = result.scalar_one_or_none()
    if not user:
        await message.answer("ابتدا /start بزنید.")
        return
    await message.answer(texts.profile_text(user))
