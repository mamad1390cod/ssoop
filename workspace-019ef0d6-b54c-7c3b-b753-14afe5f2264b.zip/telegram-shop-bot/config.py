"""تنظیمات برنامه - خواندن از فایل .env"""
import os
from pathlib import Path
from typing import Optional
from dotenv import load_dotenv

load_dotenv()

# مسیرها
BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
LOGS_DIR = BASE_DIR / "logs"
UPLOADS_DIR = DATA_DIR / "uploads"
RECEIPTS_DIR = DATA_DIR / "receipts"
BACKUPS_DIR = DATA_DIR / "backups"

# ایجاد پوشه‌ها
for _d in (DATA_DIR, LOGS_DIR, UPLOADS_DIR, RECEIPTS_DIR, BACKUPS_DIR):
    _d.mkdir(parents=True, exist_ok=True)


def _get(key: str, default: Optional[str] = None, required: bool = False) -> str:
    val = os.getenv(key, default)
    if required and not val:
        raise RuntimeError(f"❌ متغیر {key} در فایل .env تنظیم نشده است")
    return val or ""


def _get_int(key: str, default: int = 0) -> int:
    try:
        return int(os.getenv(key, str(default)))
    except (ValueError, TypeError):
        return default


def _get_list(key: str) -> list[int]:
    val = os.getenv(key, "").strip()
    if not val:
        return []
    return [int(x.strip()) for x in val.split(",") if x.strip().isdigit()]


# ============== تلگرام ==============
BOT_TOKEN: str = _get("BOT_TOKEN", required=True)
ADMIN_CHAT_ID: int = _get_int("ADMIN_CHAT_ID")
ADMIN_GROUP_ID: int = _get_int("ADMIN_GROUP_ID")
ADMIN_IDS: list[int] = _get_list("ADMIN_IDS")

# ============== دیتابیس ==============
DATABASE_TYPE: str = _get("DATABASE_TYPE", "sqlite").lower()
DATABASE_URL: str = _get("DATABASE_URL", "sqlite:///data/database.db")

# تبدیل URL به async
def _make_async_url(url: str) -> str:
    """تبدیل URL همگام به ناهمگام"""
    if DATABASE_TYPE == "sqlite":
        # sqlite:///data/database.db → sqlite+aiosqlite:///data/database.db
        if url.startswith("sqlite:///"):
            return url.replace("sqlite:///", "sqlite+aiosqlite:///", 1)
        if url.startswith("sqlite://"):
            return url.replace("sqlite://", "sqlite+aiosqlite://", 1)
        return url
    elif DATABASE_TYPE == "mysql":
        # mysql+asyncmy://...
        if "asyncmy" not in url:
            return url.replace("mysql://", "mysql+asyncmy://", 1)
        return url
    return url


ASYNC_DATABASE_URL: str = _make_async_url(DATABASE_URL)

# ============== امنیت ==============
ADMIN_PASSWORD: str = _get("ADMIN_PASSWORD", "")

# ============== پرداخت ==============
CARD_NUMBER: str = _get("CARD_NUMBER")
CARD_OWNER_NAME: str = _get("CARD_OWNER_NAME")
CARD_SHEBA: str = _get("CARD_SHEBA")
BANK_NAME: str = _get("BANK_NAME")
PAYMENT_MERCHANT_ID: str = _get("PAYMENT_MERCHANT_ID")
PAYMENT_API_KEY: str = _get("PAYMENT_API_KEY")
PAYMENT_GATEWAY_TYPE: str = _get("PAYMENT_GATEWAY_TYPE", "zarinpal")
PAYMENT_CALLBACK_URL: str = _get("PAYMENT_CALLBACK_URL")

# ============== سایر ==============
SHOP_NAME: str = _get("SHOP_NAME", "فروشگاه")
TIMEZONE: str = _get("TIMEZONE", "Asia/Tehran")
LOG_LEVEL: str = _get("LOG_LEVEL", "INFO")


def is_admin(telegram_id: int) -> bool:
    """بررسی اینکه آیا کاربر ادمین هست یا نه"""
    return telegram_id in ADMIN_IDS
