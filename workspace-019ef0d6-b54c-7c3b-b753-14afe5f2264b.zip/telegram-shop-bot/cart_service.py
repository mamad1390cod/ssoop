"""سرویس سبد خرید - ذخیره در دیتابیس

سبد خرید در دیتابیس ذخیره می‌شود و در ری‌استارت ربات از بین نمی‌رود.
پاکسازی خودکار سبدهای منقضی شده.
"""
import asyncio
import logging
from datetime import datetime, timedelta, timezone
from typing import Optional

from sqlalchemy import delete, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from database import get_session
from models import CartItem, Product, User


logger = logging.getLogger(__name__)


# ثابت‌ها
CART_TTL_MINUTES = 120  # ۲ ساعت


class CartService:
    """سرویس سبد خرید با ذخیره‌سازی در دیتابیس."""

    @staticmethod
    async def _get_or_create_user(telegram_id: int, session: AsyncSession) -> User:
        """دریافت یا ساخت کاربر."""
        result = await session.execute(
            select(User).where(User.telegram_id == telegram_id)
        )
        user = result.scalar_one_or_none()
        if not user:
            user = User(
                telegram_id=telegram_id,
                registered_at=datetime.now(timezone.utc),
            )
            session.add(user)
            await session.flush()
            await session.refresh(user)
        return user

    @staticmethod
    async def get_cart(telegram_id: int) -> list[CartItem]:
        """دریافت اقلام سبد خرید کاربر."""
        async with get_session() as session:
            user = await CartService._get_or_create_user(telegram_id, session)
            await CartService._update_last_activity(user.id, session)

            # پاکسازی اقلام منقضی شده
            await CartService._cleanup_user_cart(user.id, session)

            result = await session.execute(
                select(CartItem)
                .where(CartItem.user_id == user.id)
                .order_by(CartItem.created_at)
            )
            return list(result.scalars().all())

    @staticmethod
    async def add_item(
        telegram_id: int,
        product_id: int,
        quantity: int = 1,
    ) -> tuple[bool, str]:
        """افزودن محصول به سبد خرید.

        Returns:
            (success, error_message)
        """
        if quantity <= 0:
            return False, "تعداد باید بیشتر از صفر باشد"

        async with get_session() as session:
            user = await CartService._get_or_create_user(telegram_id, session)

            # بررسی موجودی محصول
            product = await session.get(Product, product_id)
            if not product or product.is_deleted:
                return False, "محصول یافت نشد"
            if not product.is_active:
                return False, "این محصول فعال نیست"
            if product.is_vip_only:
                return False, "این محصول فقط برای کاربران ویژه است"
            if product.track_inventory:
                # بررسی موجودی با احتساب سبد فعلی
                result = await session.execute(
                    select(CartItem).where(
                        CartItem.user_id == user.id,
                        CartItem.product_id == product_id,
                    )
                )
                existing = result.scalar_one_or_none()
                current_qty = existing.quantity if existing else 0
                if product.stock < current_qty + quantity:
                    return False, f"موجودی کافی نیست (موجود: {product.stock})"

            # افزودن یا بروزرسانی
            result = await session.execute(
                select(CartItem).where(
                    CartItem.user_id == user.id,
                    CartItem.product_id == product_id,
                )
            )
            existing = result.scalar_one_or_none()

            if existing:
                existing.quantity += quantity
                existing.updated_at = datetime.now(timezone.utc)
            else:
                cart_item = CartItem(
                    user_id=user.id,
                    product_id=product_id,
                    quantity=quantity,
                    price_snapshot=product.effective_price,
                )
                session.add(cart_item)

            # بروزرسانی فعالیت کاربر
            await CartService._update_last_activity(user.id, session)
            return True, ""

    @staticmethod
    async def update_quantity(
        telegram_id: int,
        product_id: int,
        quantity: int,
    ) -> tuple[bool, str]:
        """بروزرسانی تعداد یک محصول در سبد."""
        async with get_session() as session:
            user = await CartService._get_or_create_user(telegram_id, session)

            result = await session.execute(
                select(CartItem).where(
                    CartItem.user_id == user.id,
                    CartItem.product_id == product_id,
                )
            )
            item = result.scalar_one_or_none()
            if not item:
                return False, "محصول در سبد یافت نشد"

            if quantity <= 0:
                await session.delete(item)
                return True, ""

            # بررسی موجودی
            product = await session.get(Product, product_id)
            if product and product.track_inventory and product.stock < quantity:
                return False, f"موجودی کافی نیست (موجود: {product.stock})"

            item.quantity = quantity
            item.updated_at = datetime.now(timezone.utc)
            await CartService._update_last_activity(user.id, session)
            return True, ""

    @staticmethod
    async def remove_item(telegram_id: int, product_id: int) -> bool:
        """حذف محصول از سبد."""
        async with get_session() as session:
            user = await CartService._get_or_create_user(telegram_id, session)
            result = await session.execute(
                delete(CartItem).where(
                    CartItem.user_id == user.id,
                    CartItem.product_id == product_id,
                )
            )
            await CartService._update_last_activity(user.id, session)
            return result.rowcount > 0

    @staticmethod
    async def clear_cart(telegram_id: int) -> int:
        """خالی کردن کامل سبد خرید.

        Returns: تعداد اقلام حذف شده
        """
        async with get_session() as session:
            user = await CartService._get_or_create_user(telegram_id, session)
            result = await session.execute(
                delete(CartItem).where(CartItem.user_id == user.id)
            )
            return result.rowcount or 0

    @staticmethod
    async def cart_total(telegram_id: int) -> int:
        """محاسبه مجموع قیمت سبد."""
        async with get_session() as session:
            user = await CartService._get_or_create_user(telegram_id, session)
            result = await session.execute(
                select(CartItem).where(CartItem.user_id == user.id)
            )
            items = result.scalars().all()
            total = 0
            for item in items:
                # استفاده از قیمت snapshot یا قیمت فعلی محصول
                product = await session.get(Product, item.product_id)
                if not product or product.is_deleted:
                    continue
                price = product.effective_price
                total += price * item.quantity
            return total

    @staticmethod
    async def cart_count(telegram_id: int) -> int:
        """تعداد اقلام در سبد."""
        async with get_session() as session:
            user = await CartService._get_or_create_user(telegram_id, session)
            from sqlalchemy import func

            result = await session.execute(
                select(func.coalesce(func.sum(CartItem.quantity), 0)).where(
                    CartItem.user_id == user.id
                )
            )
            return int(result.scalar_one() or 0)

    @staticmethod
    async def get_cart_with_products(telegram_id: int) -> list[tuple[Product, int]]:
        """دریافت سبد با محصولات (برای نمایش)."""
        async with get_session() as session:
            user = await CartService._get_or_create_user(telegram_id, session)
            result = await session.execute(
                select(CartItem).where(CartItem.user_id == user.id)
            )
            items = result.scalars().all()
            result_list = []
            for item in items:
                product = await session.get(Product, item.product_id)
                if product and not product.is_deleted and product.is_active:
                    result_list.append((product, item.quantity))
            return result_list

    @staticmethod
    async def validate_for_checkout(
        telegram_id: int,
    ) -> tuple[bool, list[str], int, list[tuple[Product, int]]]:
        """اعتبارسنجی سبد قبل از پرداخت.

        Returns:
            (valid, errors, total, items)
        """
        items = await CartService.get_cart_with_products(telegram_id)
        if not items:
            return False, ["سبد خرید خالی است"], 0, []

        errors = []
        total = 0
        async with get_session() as session:
            user = await CartService._get_or_create_user(telegram_id, session)
            result = await session.execute(
                select(CartItem).where(CartItem.user_id == user.id)
            )
            cart_items = list(result.scalars().all())

            valid_items = []
            for item in cart_items:
                product = await session.get(Product, item.product_id)
                if not product or product.is_deleted:
                    errors.append(f"محصول دیگر موجود نیست")
                    continue
                if not product.is_active:
                    errors.append(f"محصول «{product.name}» غیرفعال شد")
                    continue
                if product.track_inventory and product.stock < item.quantity:
                    errors.append(
                        f"موجودی «{product.name}» کافی نیست (موجود: {product.stock})"
                    )
                    continue
                price = product.effective_price
                total += price * item.quantity
                valid_items.append((product, item.quantity))

            # حذف اقلام نامعتبر
            if len(valid_items) != len(cart_items):
                valid_pids = {p.id for p, _ in valid_items}
                for item in cart_items:
                    if item.product_id not in valid_pids:
                        await session.delete(item)

        return len(errors) == 0, errors, total, valid_items

    @staticmethod
    async def clear_after_order(telegram_id: int) -> int:
        """خالی کردن سبد پس از ثبت موفق سفارش."""
        return await CartService.clear_cart(telegram_id)

    # ============== توابع کمکی داخلی ==============

    @staticmethod
    async def _update_last_activity(user_id: int, session: AsyncSession):
        """بروزرسانی زمان آخرین فعالیت کاربر."""
        try:
            await session.execute(
                update(User)
                .where(User.id == user_id)
                .values(last_activity_at=datetime.now(timezone.utc))
            )
        except Exception:
            pass  # اگر ستون وجود نداشت، نادیده بگیر

    @staticmethod
    async def _cleanup_user_cart(user_id: int, session: AsyncSession):
        """پاکسازی سبد کاربر - اقلام منقضی شده."""
        try:
            # اقلامی که بیش از ۲ ساعت تغییر نکرده‌اند منقضی می‌شوند
            cutoff = datetime.now(timezone.utc) - timedelta(minutes=CART_TTL_MINUTES)
            await session.execute(
                delete(CartItem).where(
                    CartItem.user_id == user_id,
                    CartItem.updated_at < cutoff,
                )
            )
        except Exception:
            pass

    @staticmethod
    async def cleanup_all_expired_carts() -> int:
        """پاکسازی همه سبدهای منقضی شده - فراخوانی دوره‌ای."""
        try:
            cutoff = datetime.now(timezone.utc) - timedelta(minutes=CART_TTL_MINUTES)
            async with get_session() as session:
                result = await session.execute(
                    delete(CartItem).where(CartItem.updated_at < cutoff)
                )
                deleted = result.rowcount or 0
                if deleted > 0:
                    logger.info(f"Cleaned up {deleted} expired cart items")
                return deleted
        except Exception as e:
            logger.error(f"Cart cleanup failed: {e}")
            return 0


# تسک پس‌زمینه برای پاکسازی دوره‌ای
async def cart_cleanup_task():
    """تسک دوره‌ای پاکسازی سبدهای منقضی شده - هر ۳۰ دقیقه."""
    while True:
        try:
            await asyncio.sleep(1800)  # ۳۰ دقیقه
            await CartService.cleanup_all_expired_carts()
        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.error(f"Cleanup task error: {e}")
            await asyncio.sleep(60)
