"""پنل مدیریت - با وضعیت‌های جدید و رفع کامل باگ‌ها"""
import logging
import shutil
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)
from sqlalchemy import func, select
from sqlalchemy.orm import joinedload

import config
import keyboards
import models
import texts
import utils
from database import get_session
from models import (
    ACTIVE_ORDER_STATUSES,
    ARCHIVED_ORDER_STATUSES,
    AdminSession,
    Category,
    Coupon,
    Order,
    OrderStatus,
    OrderStatusHistory,
    Product,
    SALES_COUNTED_STATUSES,
    User,
)
from order_service import OrderService
from payments import approve_payment, reject_payment


logger = logging.getLogger(__name__)


# ============== حالت‌ها ==============

class AdminStates(StatesGroup):
    waiting_password = State()
    add_product_name = State()
    add_product_desc = State()
    add_product_price = State()
    add_product_stock = State()
    add_product_category = State()
    add_category_name = State()
    add_coupon_code = State()
    add_coupon_value = State()
    add_coupon_expires = State()
    broadcast_message = State()
    reject_reason = State()


# ============== Router ==============

admin_router = Router(name="admin")


# ============== احراز هویت ==============

ADMIN_SESSIONS: dict[int, datetime] = {}


async def is_authenticated(telegram_id: int) -> bool:
    """بررسی معتبر بودن نشست ادمین - ایمن در برابر naive/aware datetime."""
    now = datetime.now(timezone.utc)

    exp = ADMIN_SESSIONS.get(telegram_id)
    if exp:
        if exp.tzinfo is None:
            exp = exp.replace(tzinfo=timezone.utc)
        if exp > now:
            return True

    async with get_session() as session:
        result = await session.execute(
            select(AdminSession).where(
                AdminSession.telegram_id == telegram_id,
                AdminSession.expires_at > now,
            ).order_by(AdminSession.created_at.desc()).limit(1)
        )
        sess = result.scalar_one_or_none()
        if sess:
            exp_at = sess.expires_at
            if exp_at.tzinfo is None:
                exp_at = exp_at.replace(tzinfo=timezone.utc)
            ADMIN_SESSIONS[telegram_id] = exp_at
            return True
    return False


async def create_session(telegram_id: int) -> AdminSession:
    async with get_session() as session:
        from sqlalchemy import delete

        await session.execute(
            delete(AdminSession).where(AdminSession.telegram_id == telegram_id)
        )
        expires = datetime.now(timezone.utc) + timedelta(hours=2)
        sess = AdminSession(
            telegram_id=telegram_id,
            token=utils.gen_token(32),
            expires_at=expires,
        )
        session.add(sess)
        await session.flush()
        await session.refresh(sess)
        ADMIN_SESSIONS[telegram_id] = expires
        return sess


async def destroy_session(telegram_id: int) -> None:
    ADMIN_SESSIONS.pop(telegram_id, None)
    async with get_session() as session:
        from sqlalchemy import delete

        await session.execute(
            delete(AdminSession).where(AdminSession.telegram_id == telegram_id)
        )


# ============== ورود ==============

@admin_router.message(F.text == "⚙️ پنل مدیریت")
@admin_router.message(Command("admin"))
async def cmd_admin(message: Message, state: FSMContext):
    """شروع فرآیند ورود امن."""
    if not config.is_admin(message.from_user.id):
        await message.answer(texts.ADMIN_NOT_AUTHORIZED)
        return
    if not config.ADMIN_PASSWORD:
        await message.answer("❌ رمز ادمین در .env تنظیم نشده است.")
        return
    if await is_authenticated(message.from_user.id):
        await message.answer(texts.ADMIN_ACTIVE)
        await message.answer(texts.ADMIN_PANEL, reply_markup=keyboards.admin_main_kb())
        return

    await state.set_state(AdminStates.waiting_password)
    try:
        await message.delete()
    except Exception:
        pass
    await message.answer(
        texts.ADMIN_PASSWORD_REQUEST,
        reply_markup=keyboards.cancel_kb(),
    )


@admin_router.message(AdminStates.waiting_password)
async def process_password(message: Message, state: FSMContext):
    password = utils.get_text(message)
    if not password:
        await message.answer(texts.ADMIN_PASSWORD_WRONG)
        return
    if password != config.ADMIN_PASSWORD:
        logger.warning(f"Failed admin login from telegram_id={message.from_user.id}")
        await message.answer(texts.ADMIN_PASSWORD_WRONG)
        return

    await create_session(message.from_user.id)
    await state.clear()
    try:
        await message.delete()
    except Exception:
        pass
    await message.answer(
        texts.ADMIN_LOGIN_OK,
        reply_markup=keyboards.main_menu(message.from_user.id),
    )
    await message.answer(
        texts.ADMIN_PANEL,
        reply_markup=keyboards.admin_main_kb(),
    )


# ============== خروج ==============

@admin_router.callback_query(F.data == "adm:logout")
async def cb_logout(callback: CallbackQuery, state: FSMContext):
    await destroy_session(callback.from_user.id)
    await state.clear()
    await callback.message.edit_text(texts.ADMIN_LOGOUT_OK)
    await callback.answer()
    await callback.message.answer(
        texts.WELCOME_BACK.format(name=callback.from_user.first_name or ""),
        reply_markup=keyboards.main_menu(callback.from_user.id),
    )


# ============== بازگشت ==============

@admin_router.callback_query(F.data == "adm:back")
async def cb_back(callback: CallbackQuery, state: FSMContext):
    if not await is_authenticated(callback.from_user.id):
        await callback.answer("نشست منقضی شده", show_alert=True)
        return
    await state.clear()
    await callback.message.edit_text(
        texts.ADMIN_PANEL,
        reply_markup=keyboards.admin_main_kb(),
    )
    await callback.answer()


# ============== داشبورد (با آمار صحیح) ==============

@admin_router.callback_query(F.data == "adm:dash")
async def cb_dashboard(callback: CallbackQuery):
    if not await is_authenticated(callback.from_user.id):
        return
    async with get_session() as session:
        users_count = (await session.execute(
            select(func.count(User.id)).where(User.is_deleted == False)
        )).scalar() or 0
        products_count = (await session.execute(
            select(func.count(Product.id)).where(
                Product.is_active == True, Product.is_deleted == False
            )
        )).scalar() or 0

        # آمار فروش از OrderService (محاسبه از total_amount که ثابت است)
        sales_stats = await OrderService.get_sales_stats()
        total_orders = sales_stats["total_orders"]
        pending_orders = sales_stats["pending_orders"]

    stats = {
        "users_count": users_count,
        "products_count": products_count,
        "total_orders": total_orders,
        "pending_orders": pending_orders,
        **sales_stats,
    }
    await callback.message.edit_text(
        texts.admin_dashboard_text(stats),
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[
                [keyboards.back_button("adm:back", "🔙 پنل")]
            ]
        ),
        parse_mode="HTML",
    )
    await callback.answer()


# ============== مدیریت محصولات ==============

@admin_router.callback_query(F.data == "adm:products")
async def cb_products(callback: CallbackQuery):
    if not await is_authenticated(callback.from_user.id):
        return
    async with get_session() as session:
        result = await session.execute(
            select(Product)
            .where(Product.is_deleted == False)
            .order_by(Product.id.desc())
            .limit(30)
        )
        products = result.scalars().all()
    await callback.message.edit_text(
        "🛍 <b>محصولات</b>\n\nروی محصول برای حذف کلیک کنید:",
        reply_markup=keyboards.admin_products_kb(products),
    )
    await callback.answer()


@admin_router.callback_query(F.data == "adm:addprod")
async def cb_add_product(callback: CallbackQuery, state: FSMContext):
    if not await is_authenticated(callback.from_user.id):
        return
    async with get_session() as session:
        result = await session.execute(
            select(Category)
            .where(Category.is_active == True, Category.is_deleted == False)
            .order_by(Category.sort_order)
        )
        cats = result.scalars().all()
    if not cats:
        await callback.answer("ابتدا یک دسته بسازید!", show_alert=True)
        return
    await state.set_state(AdminStates.add_product_category)
    await callback.message.edit_text(
        "📂 دسته محصول را انتخاب کنید:",
        reply_markup=keyboards.admin_category_select_kb(cats),
    )
    await callback.answer()


@admin_router.callback_query(F.data.startswith("addprod:cat:"))
async def addprod_category(callback: CallbackQuery, state: FSMContext):
    if not await is_authenticated(callback.from_user.id):
        return
    cat_id = int(callback.data.split(":")[2])
    await state.update_data(category_id=cat_id)
    await state.set_state(AdminStates.add_product_name)
    await callback.message.edit_text("📝 <b>نام محصول</b> (برای لغو: ردشدن):")
    await callback.answer()


@admin_router.message(AdminStates.add_product_name)
async def addprod_name(message: Message, state: FSMContext):
    if not await is_authenticated(message.from_user.id):
        return
    if utils.is_skip(message.text):
        await state.clear()
        await message.answer(
            texts.CANCEL,
            reply_markup=keyboards.main_menu(message.from_user.id),
        )
        return
    name = utils.get_text(message)
    if not name:
        await message.answer("❌ نام نمی‌تواند خالی باشد:")
        return
    await state.update_data(name=name)
    await state.set_state(AdminStates.add_product_desc)
    await message.answer(
        "📄 <b>توضیحات</b>\n\nبرای رد شدن: <code>ردشدن</code> یا <code>-</code>"
    )


@admin_router.message(AdminStates.add_product_desc)
async def addprod_desc(message: Message, state: FSMContext):
    if not await is_authenticated(message.from_user.id):
        return
    if utils.is_skip(message.text):
        await state.update_data(description=None)
        await message.answer("✅ توضیحات رد شد")
    else:
        desc = utils.get_text(message)
        if not desc:
            await message.answer(
                "❌ توضیحات خالی است. متن بفرستید یا <code>ردشدن</code>:"
            )
            return
        await state.update_data(description=desc)
    await state.set_state(AdminStates.add_product_price)
    await message.answer("💰 <b>قیمت</b> (تومان):")


@admin_router.message(AdminStates.add_product_price)
async def addprod_price(message: Message, state: FSMContext):
    if not await is_authenticated(message.from_user.id):
        return
    text = utils.get_text(message)
    if utils.is_skip(text):
        price = 0
    else:
        try:
            price = int(utils.en(text))
            if price < 0:
                raise ValueError
        except ValueError:
            await message.answer(
                "❌ قیمت نامعتبر. عدد مثبت یا <code>ردشدن</code>:"
            )
            return
    await state.update_data(price=price)
    await state.set_state(AdminStates.add_product_stock)
    await message.answer("📦 <b>موجودی</b> (عدد یا <code>ردشدن</code>):")


@admin_router.message(AdminStates.add_product_stock)
async def addprod_stock(message: Message, state: FSMContext):
    if not await is_authenticated(message.from_user.id):
        return
    text = utils.get_text(message)
    if utils.is_skip(text):
        stock = 0
    else:
        try:
            stock = int(utils.en(text))
            if stock < 0:
                raise ValueError
        except ValueError:
            await message.answer("❌ موجودی نامعتبر:")
            return
    data = await state.get_data()
    if not data.get("name"):
        await state.clear()
        await message.answer(
            "❌ خطا: نام محصول خالی است.", reply_markup=keyboards.main_menu(message.from_user.id)
        )
        return

    async with get_session() as session:
        p = Product(
            name=data["name"],
            description=data.get("description"),
            price=data["price"],
            stock=stock,
            category_id=data["category_id"],
            sku=f"SKU-{utils.gen_token(4).upper()}",
            slug=data["name"].lower().replace(" ", "-"),
        )
        session.add(p)
    await state.clear()
    await message.answer(
        f"✅ محصول «{data['name']}» اضافه شد!",
        reply_markup=keyboards.main_menu(message.from_user.id),
    )


@admin_router.callback_query(F.data.startswith("adm:delprod:"))
async def cb_del_product(callback: CallbackQuery):
    if not await is_authenticated(callback.from_user.id):
        return
    pid = int(callback.data.split(":")[2])
    async with get_session() as session:
        p = await session.get(Product, pid)
        if p:
            p.is_deleted = True
    await callback.answer("✅ حذف شد")
    await cb_products(callback)


# ============== مدیریت دسته‌ها ==============

@admin_router.callback_query(F.data == "adm:categories")
async def cb_categories(callback: CallbackQuery):
    if not await is_authenticated(callback.from_user.id):
        return
    async with get_session() as session:
        result = await session.execute(
            select(Category).where(Category.is_deleted == False).order_by(Category.sort_order)
        )
        cats = result.scalars().all()
    await callback.message.edit_text(
        "📂 <b>دسته‌ها</b>",
        reply_markup=keyboards.admin_categories_kb(cats),
    )
    await callback.answer()


@admin_router.callback_query(F.data == "adm:addcat")
async def cb_add_cat(callback: CallbackQuery, state: FSMContext):
    if not await is_authenticated(callback.from_user.id):
        return
    await state.set_state(AdminStates.add_category_name)
    await callback.message.edit_text(
        "📝 <b>نام دسته + ایموجی</b>\nمثال: 📱 موبایل\n\nبرای لغو: ردشدن"
    )
    await callback.answer()


@admin_router.message(AdminStates.add_category_name)
async def addcat_name(message: Message, state: FSMContext):
    if not await is_authenticated(message.from_user.id):
        return
    if utils.is_skip(message.text):
        await state.clear()
        await message.answer(
            texts.CANCEL,
            reply_markup=keyboards.main_menu(message.from_user.id),
        )
        return
    text = utils.get_text(message)
    if not text:
        await message.answer("❌ نام نمی‌تواند خالی باشد:")
        return
    icon = "📂"
    name = text
    for ch in text:
        if ord(ch) > 127:
            icon = ch
            name = text[len(icon):].strip()
            break
    if not name:
        name = "بدون نام"
    async with get_session() as session:
        c = Category(
            name=name,
            icon=icon,
            slug=name.lower().replace(" ", "-") or f"cat-{utils.gen_token(4).lower()}",
        )
        session.add(c)
    await state.clear()
    await message.answer(
        f"✅ دسته «{name}» اضافه شد!",
        reply_markup=keyboards.main_menu(message.from_user.id),
    )


@admin_router.callback_query(F.data.startswith("adm:delcat:"))
async def cb_del_cat(callback: CallbackQuery):
    if not await is_authenticated(callback.from_user.id):
        return
    cid = int(callback.data.split(":")[2])
    async with get_session() as session:
        c = await session.get(Category, cid)
        if c:
            c.is_deleted = True
    await callback.answer("✅ حذف شد")
    await cb_categories(callback)


# ============== مدیریت سفارشات ==============

@admin_router.callback_query(F.data == "adm:orders")
async def cb_orders(callback: CallbackQuery):
    """لیست سفارشات فعال."""
    if not await is_authenticated(callback.from_user.id):
        return
    async with get_session() as session:
        result = await session.execute(
            select(Order)
            .where(
                Order.status.in_(ACTIVE_ORDER_STATUSES),
                Order.is_deleted == False,
            )
            .order_by(Order.created_at.asc())
            .limit(30)
        )
        orders = result.scalars().all()
    if not orders:
        await callback.message.edit_text(
            "📭 سفارش فعالی نیست.",
            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(text="🗄 آرشیو", callback_data="adm:archive"),
                        keyboards.back_button("adm:back", "🔙 پنل"),
                    ]
                ]
            ),
        )
        return
    await callback.message.edit_text(
        "📦 <b>سفارشات فعال</b>\n(در انتظار پرداخت، پرداخت شده، در حال پردازش، آماده ارسال)",
        reply_markup=keyboards.admin_orders_kb(orders),
    )
    await callback.answer()


@admin_router.callback_query(F.data == "adm:archive")
async def cb_archive(callback: CallbackQuery):
    """آرشیو سفارشات (ارسال، تکمیل، لغو)."""
    if not await is_authenticated(callback.from_user.id):
        return
    async with get_session() as session:
        result = await session.execute(
            select(Order)
            .where(
                Order.status.in_(ARCHIVED_ORDER_STATUSES),
                Order.is_deleted == False,
            )
            .order_by(Order.updated_at.desc())
            .limit(30)
        )
        orders = result.scalars().all()
    if not orders:
        await callback.message.edit_text(
            "📭 سفارش آرشیو شده‌ای نیست.",
            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [InlineKeyboardButton(text="📦 فعال", callback_data="adm:orders")],
                    [keyboards.back_button("adm:back", "🔙 پنل")],
                ]
            ),
        )
        return
    await callback.message.edit_text(
        "🗄 <b>آرشیو سفارشات</b>\n(ارسال شده، تکمیل شده، لغو شده)",
        reply_markup=keyboards.admin_archive_kb(orders),
    )
    await callback.answer()


@admin_router.callback_query(F.data.startswith("adm:order:"))
async def cb_order_detail(callback: CallbackQuery):
    """جزئیات سفارش."""
    if not await is_authenticated(callback.from_user.id):
        return
    oid = int(callback.data.split(":")[2])
    async with get_session() as session:
        order = await session.get(Order, oid)
        if not order:
            await callback.answer("یافت نشد")
            return
        items = await OrderService.list_items(oid)
        history = await OrderService.get_status_history(oid)

    items_text = "\n".join(
        f"▫️ {it.product_name} × {utils.fa(it.quantity)} = {utils.fa(f'{it.total_price:,}')} تومان"
        for it in items
    )

    text = texts.admin_order_detail_text(order, items_text)

    # نمایش تاریخچه اگر وجود دارد
    if history:
        history_text = "\n\n<b>📜 تاریخچه:</b>\n"
        for h in history[-5:]:  # آخرین ۵ تغییر
            from_label = texts.get_status_label(h.from_status) if h.from_status else "—"
            to_label = texts.get_status_label(h.to_status)
            history_text += f"▫️ {from_label} → {to_label}\n"
            if h.reason:
                history_text += f"   📝 {h.reason}\n"
        text += history_text

    await callback.message.edit_text(
        text,
        reply_markup=keyboards.admin_order_actions_kb(order.id, order.status),
    )
    await callback.answer()


# ============== تغییر وضعیت سفارش ==============

@admin_router.callback_query(F.data.startswith("adm:setstatus:"))
async def cb_set_status(callback: CallbackQuery):
    """تغییر وضعیت سفارش به مرحله بعد."""
    if not await is_authenticated(callback.from_user.id):
        return
    parts = callback.data.split(":")
    # Format: adm:setstatus:<order_id>:<new_status>
    order_id = int(parts[2])
    new_status = parts[3]

    valid_statuses = [s.value for s in OrderStatus]
    if new_status not in valid_statuses:
        await callback.answer("وضعیت نامعتبر", show_alert=True)
        return

    order = await OrderService.change_status(
        order_id,
        new_status,
        changed_by=str(callback.from_user.id),
        changed_by_telegram_id=callback.from_user.id,
        reason=f"Changed by admin {callback.from_user.id}",
    )
    if order is None:
        await callback.answer("خطا در تغییر وضعیت", show_alert=True)
        return

    await callback.answer(f"✅ {texts.get_status_label(new_status)}")

    # ارسال اعلان به کاربر
    bot = callback.bot
    try:
        user = order.user
        if user:
            await bot.send_message(
                user.telegram_id,
                f"📊 وضعیت سفارش {order.order_number}: {texts.get_status_label(new_status)}",
            )
    except Exception:
        pass

    # بروزرسانی نمایش
    await cb_order_detail(callback)


# ============== تایید/رد پرداخت ==============

@admin_router.callback_query(F.data.startswith("adm:approve:"))
async def cb_approve(callback: CallbackQuery, bot=None):
    """تایید پرداخت کارت به کارت."""
    if not await is_authenticated(callback.from_user.id):
        return
    pid = int(callback.data.split(":")[2])

    # پیدا کردن payment
    async with get_session() as session:
        result = await session.execute(
            select(models.Payment)
            .options(joinedload(models.Payment.order).joinedload(Order.user))
            .where(models.Payment.order_id == pid, models.Payment.status == "pending")
        )
        pay = result.scalar_one_or_none()
        if not pay:
            await callback.answer("پرداختی یافت نشد یا قبلاً تایید شده", show_alert=True)
            return
        payment_id = pay.id
        order_id = pay.order_id

    # تایید پرداخت (از طریق OrderService برای ثبت در تاریخچه)
    order = await approve_payment(
        payment_id,
        changed_by=str(callback.from_user.id),
        changed_by_telegram_id=callback.from_user.id,
    )
    if order is None:
        await callback.answer("خطا", show_alert=True)
        return

    # اطلاع به کاربر
    if bot:
        try:
            async with get_session() as session:
                order_with_user = await session.get(Order, order_id)
                if order_with_user and order_with_user.user:
                    await bot.send_message(
                        order_with_user.user.telegram_id,
                        f"✅ پرداخت سفارش {order_with_user.order_number} تایید شد!\n"
                        f"سفارش شما در حال پردازش است.",
                    )
        except Exception:
            pass

    await callback.answer("✅ تایید شد")

    # بازگشت به لیست
    await cb_orders(callback)


@admin_router.callback_query(F.data.startswith("adm:reject:"))
async def cb_reject_start(callback: CallbackQuery, state: FSMContext):
    """شروع فرآیند رد پرداخت."""
    if not await is_authenticated(callback.from_user.id):
        return
    oid = int(callback.data.split(":")[2])
    await state.set_state(AdminStates.reject_reason)
    async with state.proxy() as data:
        data["order_id"] = oid
    await callback.message.edit_text(
        "❌ <b>دلیل رد پرداخت</b> را وارد کنید:",
    )
    await callback.answer()


@admin_router.message(AdminStates.reject_reason)
async def cb_reject_reason(message: Message, state: FSMContext, bot=None):
    if not await is_authenticated(message.from_user.id):
        return
    reason = utils.get_text(message)
    if not reason:
        await message.answer("❌ دلیل رد نمی‌تواند خالی باشد:")
        return
    data = await state.get_data()
    oid = data.get("order_id")
    await state.clear()

    # پیدا کردن payment
    async with get_session() as session:
        result = await session.execute(
            select(models.Payment)
            .options(joinedload(models.Payment.order).joinedload(Order.user))
            .where(models.Payment.order_id == oid, models.Payment.status == "pending")
        )
        pay = result.scalar_one_or_none()
        if not pay:
            await message.answer("❌ پرداختی یافت نشد")
            return
        payment_id = pay.id
        user_tid = pay.order.user.telegram_id if pay.order.user else 0
        order_num = pay.order.order_number if pay.order else "?"

    await reject_payment(
        payment_id, reason,
        changed_by=str(message.from_user.id),
        changed_by_telegram_id=message.from_user.id,
    )

    if bot and user_tid:
        try:
            await bot.send_message(
                user_tid,
                f"❌ پرداخت سفارش {order_num} رد شد.\n\n📌 دلیل: {reason}\n\nلطفاً دوباره تلاش کنید.",
            )
        except Exception:
            pass

    await message.answer("✅ رد شد")


# ============== لغو سفارش ==============

@admin_router.callback_query(F.data.startswith("adm:cancel:"))
async def cb_cancel_order(callback: CallbackQuery, bot=None):
    """لغو سفارش (از هر وضعیتی)."""
    if not await is_authenticated(callback.from_user.id):
        return
    oid = int(callback.data.split(":")[2])

    async with get_session() as session:
        order = await session.get(Order, oid)
        if not order:
            await callback.answer("یافت نشد", show_alert=True)
            return
        if order.status in (
            OrderStatus.CANCELLED.value,
            OrderStatus.COMPLETED.value,
        ):
            await callback.answer("❌ این سفارش قابل لغو نیست", show_alert=True)
            return
        order_num = order.order_number
        user_tid = order.user.telegram_id if order.user else 0

    await OrderService.cancel_order(
        oid,
        reason=f"Cancelled by admin {callback.from_user.id}",
        changed_by=str(callback.from_user.id),
        changed_by_telegram_id=callback.from_user.id,
    )
    await callback.answer("❌ لغو شد")

    if bot and user_tid:
        try:
            await bot.send_message(
                user_tid,
                f"❌ سفارش {order_num} لغو شد.",
            )
        except Exception:
            pass

    await cb_order_detail(callback)


# ============== کاربران ==============

@admin_router.callback_query(F.data == "adm:users")
async def cb_users(callback: CallbackQuery):
    if not await is_authenticated(callback.from_user.id):
        return
    async with get_session() as session:
        result = await session.execute(
            select(User)
            .where(User.is_deleted == False)
            .order_by(User.id.desc())
            .limit(30)
        )
        users = result.scalars().all()
    text = "👥 <b>کاربران</b> (آخرین ۳۰ نفر)\n\n"
    for u in users:
        text += (
            f"#{u.id} {u.display_name} "
            f"(<code>{u.telegram_id}</code>)\n"
            f"   💰 {utils.fa(f'{u.total_spent:,}')} تومان | "
            f"📦 {utils.fa(u.orders_count)}\n"
        )
    await callback.message.edit_text(
        text,
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[
                [keyboards.back_button("adm:back", "🔙 پنل")]
            ]
        ),
    )
    await callback.answer()


# ============== کد تخفیف ==============

@admin_router.callback_query(F.data == "adm:coupons")
async def cb_coupons(callback: CallbackQuery):
    if not await is_authenticated(callback.from_user.id):
        return
    async with get_session() as session:
        result = await session.execute(
            select(Coupon)
            .where(Coupon.is_deleted == False)
            .order_by(Coupon.id.desc())
            .limit(30)
        )
        coupons = result.scalars().all()
    text = "🎁 <b>کدهای تخفیف</b>\n\n"
    for c in coupons:
        if c.discount_value <= 100:
            disc = f"{c.discount_value}٪"
        else:
            disc = f"{utils.fa(f'{c.discount_value:,}')} تومان"
        text += f"<code>{c.code}</code> - {disc} (استفاده: {utils.fa(c.used_count)}/{utils.fa(c.usage_limit or 999)})\n"
    await callback.message.edit_text(
        text,
        reply_markup=keyboards.admin_coupons_kb(coupons),
    )
    await callback.answer()


@admin_router.callback_query(F.data == "adm:addcoupon")
async def cb_add_coupon(callback: CallbackQuery, state: FSMContext):
    if not await is_authenticated(callback.from_user.id):
        return
    await state.set_state(AdminStates.add_coupon_code)
    await callback.message.edit_text(
        "🏷 <b>کد تخفیف</b> (یا <code>auto</code> برای تصادفی):"
    )
    await callback.answer()


@admin_router.message(AdminStates.add_coupon_code)
async def addcoupon_code(message: Message, state: FSMContext):
    if not await is_authenticated(message.from_user.id):
        return
    if utils.is_skip(message.text):
        await state.clear()
        await message.answer(
            texts.CANCEL,
            reply_markup=keyboards.main_menu(message.from_user.id),
        )
        return
    text = utils.get_text(message)
    if not text:
        await message.answer(
            "❌ کد نمی‌تواند خالی باشد. یا <code>auto</code>:"
        )
        return
    code = text.upper()
    if code == "AUTO":
        code = utils.gen_coupon_code()
    await state.update_data(code=code)
    await state.set_state(AdminStates.add_coupon_value)
    await message.answer(
        "💎 <b>مقدار تخفیف</b>\n\nعدد ≤ 100 = درصد\nعدد > 100 = مبلغ تومان"
    )


@admin_router.message(AdminStates.add_coupon_value)
async def addcoupon_value(message: Message, state: FSMContext):
    if not await is_authenticated(message.from_user.id):
        return
    text = utils.get_text(message)
    try:
        val = int(utils.en(text))
        if val < 0:
            raise ValueError
    except ValueError:
        await message.answer(
            "❌ عدد نامعتبر. مثال: <code>10</code> یا <code>50000</code>:"
        )
        return
    data = await state.get_data()
    if not data.get("code"):
        await state.clear()
        await message.answer("❌ خطا: عملیات لغو شد.")
        return
    async with get_session() as session:
        if val <= 100:
            c = Coupon(
                code=data["code"],
                name=data["code"],
                discount_value=val,
                discount_type=models.DiscountType.PERCENTAGE,
                valid_from=datetime.now(timezone.utc),
                valid_until=datetime.now(timezone.utc) + timedelta(days=30),
            )
        else:
            c = Coupon(
                code=data["code"],
                name=data["code"],
                discount_value=val,
                discount_type=models.DiscountType.FIXED_AMOUNT,
                valid_from=datetime.now(timezone.utc),
                valid_until=datetime.now(timezone.utc) + timedelta(days=30),
            )
        session.add(c)
    await state.clear()
    await message.answer(
        f"✅ کد تخفیف <code>{data['code']}</code> ساخته شد!",
        reply_markup=keyboards.main_menu(message.from_user.id),
    )


@admin_router.callback_query(F.data.startswith("adm:delcoupon:"))
async def cb_del_coupon(callback: CallbackQuery):
    if not await is_authenticated(callback.from_user.id):
        return
    cid = int(callback.data.split(":")[2])
    async with get_session() as session:
        c = await session.get(Coupon, cid)
        if c:
            c.is_active = False
    await callback.answer("✅ غیرفعال شد")
    await cb_coupons(callback)


# ============== پیام همگانی ==============

@admin_router.callback_query(F.data == "adm:broadcast")
async def cb_broadcast(callback: CallbackQuery, state: FSMContext):
    if not await is_authenticated(callback.from_user.id):
        return
    await state.set_state(AdminStates.broadcast_message)
    await callback.message.edit_text(
        "📣 <b>پیام همگانی</b>\n\nپیام خود را ارسال کنید:"
    )
    await callback.answer()


@admin_router.message(AdminStates.broadcast_message)
async def broadcast_send(message: Message, state: FSMContext, bot=None):
    if not await is_authenticated(message.from_user.id):
        return
    if utils.is_skip(message.text):
        await state.clear()
        await message.answer(
            texts.CANCEL,
            reply_markup=keyboards.main_menu(message.from_user.id),
        )
        return
    text = utils.get_text(message)
    if not text:
        await message.answer("❌ پیام نمی‌تواند خالی باشد:")
        return
    await state.clear()

    async with get_session() as session:
        result = await session.execute(
            select(User.telegram_id).where(
                User.is_blocked == False, User.is_deleted == False
            )
        )
        user_ids = [r[0] for r in result.all()]

    sent = 0
    failed = 0
    if bot:
        for uid in user_ids:
            try:
                await bot.send_message(uid, text)
                sent += 1
            except Exception:
                failed += 1
    await message.answer(
        f"✅ پیام همگانی ارسال شد.\n📤 موفق: {utils.fa(sent)} | ❌ ناموفق: {utils.fa(failed)}",
        reply_markup=keyboards.main_menu(message.from_user.id),
    )


# ============== بکاپ ==============

@admin_router.callback_query(F.data == "adm:backup")
async def cb_backup(callback: CallbackQuery):
    if not await is_authenticated(callback.from_user.id):
        return
    backups = sorted(config.BACKUPS_DIR.glob("backup_*.db"), reverse=True)
    await callback.message.edit_text(
        "💾 <b>مدیریت بکاپ</b>\n\n"
        "📥 ساخت بکاپ جدید\n"
        "📤 دانلود فایل بکاپ\n"
        "🔄 بازیابی\n"
        "🗑 حذف",
        reply_markup=keyboards.admin_backup_kb(backups),
    )
    await callback.answer()


@admin_router.callback_query(F.data == "adm:backup:create")
async def cb_backup_create(callback: CallbackQuery):
    if not await is_authenticated(callback.from_user.id):
        return
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_name = f"backup_{timestamp}.db"
    backup_path = config.BACKUPS_DIR / backup_name
    try:
        if config.DATABASE_TYPE == "sqlite":
            from database import _engine
            await _engine.dispose()
            shutil.copy2(config.DATA_DIR / "database.db", backup_path)
        else:
            await callback.message.edit_text("⚠️ بکاپ MySQL به‌زودی اضافه می‌شود.")
            return
        size_kb = int(backup_path.stat().st_size / 1024)
        await callback.answer(f"✅ بکاپ ساخته شد ({size_kb}KB)")
    except Exception as e:
        logger.error(f"Backup failed: {e}")
        await callback.answer("❌ خطا در ساخت بکاپ", show_alert=True)
    await cb_backup(callback)


@admin_router.callback_query(F.data.startswith("adm:backup:dl:"))
async def cb_backup_download(callback: CallbackQuery, bot=None):
    if not await is_authenticated(callback.from_user.id):
        return
    name = callback.data.split(":", 3)[3]
    file_path = config.BACKUPS_DIR / name
    if not file_path.exists():
        await callback.answer("❌ فایل یافت نشد", show_alert=True)
        return
    try:
        from aiogram.types import FSInputFile

        doc = FSInputFile(str(file_path), filename=name)
        await bot.send_document(
            callback.from_user.id,
            document=doc,
            caption=f"📁 بکاپ: {name}",
        )
        await callback.answer("✅ ارسال شد")
    except Exception as e:
        logger.error(f"Backup download failed: {e}")
        await callback.answer("❌ خطا در ارسال", show_alert=True)


@admin_router.callback_query(F.data.startswith("adm:backup:del:"))
async def cb_backup_delete(callback: CallbackQuery):
    if not await is_authenticated(callback.from_user.id):
        return
    name = callback.data.split(":", 3)[3]
    file_path = config.BACKUPS_DIR / name
    if file_path.exists():
        file_path.unlink()
    await callback.answer("✅ حذف شد")
    await cb_backup(callback)


@admin_router.callback_query(F.data.startswith("adm:backup:restore:"))
async def cb_backup_restore(callback: CallbackQuery):
    if not await is_authenticated(callback.from_user.id):
        return
    name = callback.data.split(":", 3)[3]
    file_path = config.BACKUPS_DIR / name
    if not file_path.exists():
        await callback.answer("❌ فایل یافت نشد", show_alert=True)
        return
    try:
        if config.DATABASE_TYPE == "sqlite":
            from database import _engine
            await _engine.dispose()
            dest = config.DATA_DIR / "database.db"
            shutil.copy2(file_path, dest)
            await callback.answer("✅ بازیابی شد - ربات را ری‌استارت کنید")
        else:
            await callback.answer("⚠️ بازیابی MySQL پشتیبانی نمی‌شود", show_alert=True)
    except Exception as e:
        logger.error(f"Restore failed: {e}")
        await callback.answer("❌ خطا در بازیابی", show_alert=True)
