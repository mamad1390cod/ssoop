"""تمام کیبوردها و دکمه‌ها - با دکمه‌های بازگشت در همه جا"""
from typing import Optional, Sequence

from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
)

import config
from models import (
    ACTIVE_ORDER_STATUSES,
    ARCHIVED_ORDER_STATUSES,
    Order,
    OrderStatus,
    Product,
)
from texts import (
    BTN_CANCEL,
    MENU_ADMIN,
    MENU_CART,
    MENU_CATALOG,
    MENU_ORDERS,
    MENU_PROFILE,
)


# ============== کیبورد اصلی (Reply) ==============

def main_menu(user_id: int) -> ReplyKeyboardMarkup:
    """منوی اصلی برای کاربر."""
    kb = [
        [KeyboardButton(text=MENU_CATALOG), KeyboardButton(text=MENU_CART)],
        [KeyboardButton(text=MENU_ORDERS), KeyboardButton(text=MENU_PROFILE)],
    ]
    if config.is_admin(user_id):
        kb.append([KeyboardButton(text=MENU_ADMIN)])
    return ReplyKeyboardMarkup(keyboard=kb, resize_keyboard=True)


def cancel_kb() -> ReplyKeyboardMarkup:
    """کیبورد لغو."""
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text=BTN_CANCEL)]],
        resize_keyboard=True,
    )


# ============== دکمه‌های بازگشت (استاندارد) ==============

def back_button(callback_data: str = "back:main", text: str = "🔙 بازگشت") -> InlineKeyboardButton:
    """ساخت دکمه بازگشت."""
    return InlineKeyboardButton(text=text, callback_data=callback_data)


def back_row(callback_data: str = "back:main", text: str = "🔙 بازگشت") -> list:
    """ردیف دکمه بازگشت."""
    return [back_button(callback_data, text)]


def home_button(text: str = "🏠 منوی اصلی") -> InlineKeyboardButton:
    return InlineKeyboardButton(text=text, callback_data="home:main")


def cancel_button(text: str = "❌ انصراف") -> InlineKeyboardButton:
    return InlineKeyboardButton(text=text, callback_data="cancel:action")


# ============== کیبورد دسته‌بندی ==============

def categories_kb(categories) -> InlineKeyboardMarkup:
    rows = []
    for c in categories:
        icon = c.icon or "📂"
        rows.append([
            InlineKeyboardButton(
                text=f"{icon} {c.name}",
                callback_data=f"cat:{c.id}",
            )
        ])
    rows.append([back_button("home:main", "🏠 منوی اصلی")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


# ============== کیبورد محصولات ==============

def products_kb(products, category_id: int) -> InlineKeyboardMarkup:
    from utils import fa

    buttons = []
    for p in products:
        price = p.effective_price
        buttons.append([
            InlineKeyboardButton(
                text=f"🛍 {p.name} — {fa(f'{price:,}')} تومان",
                callback_data=f"prod:{p.id}",
            )
        ])
    buttons.append([back_button("back:cats", "🔙 دسته‌ها")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def product_detail_kb(product, in_cart: int = 0) -> InlineKeyboardMarkup:
    from utils import fa

    buttons = []
    if product.stock > 0:
        buttons.append([
            InlineKeyboardButton(text="➖", callback_data=f"cart:-:{product.id}"),
            InlineKeyboardButton(text=f"🛒 {fa(in_cart)}", callback_data="noop"),
            InlineKeyboardButton(text="➕", callback_data=f"cart:+:{product.id}"),
        ])
    buttons.append([
        InlineKeyboardButton(text="🛒 سبد خرید", callback_data="show:cart"),
        back_button("back:cats", "🔙 بازگشت"),
    ])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


# ============== کیبورد سبد خرید ==============

def cart_kb(has_items: bool = True) -> InlineKeyboardMarkup:
    buttons = []
    if has_items:
        buttons.append([
            InlineKeyboardButton(text="✅ ثبت سفارش", callback_data="checkout:start"),
        ])
        buttons.append([
            InlineKeyboardButton(text="🗑 خالی کردن", callback_data="cart:clear"),
        ])
    buttons.append([
        InlineKeyboardButton(text="🛍 ادامه خرید", callback_data="back:cats"),
        back_button("home:main", "🏠 منو"),
    ])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


# ============== کیبورد روش پرداخت ==============

def payment_methods_kb(total: int) -> InlineKeyboardMarkup:
    buttons = []
    if config.PAYMENT_MERCHANT_ID:
        buttons.append([
            InlineKeyboardButton(text="💳 پرداخت آنلاین", callback_data="pay:online"),
        ])
    buttons.append([
        InlineKeyboardButton(text="🏦 کارت به کارت", callback_data="pay:card"),
    ])
    buttons.append([
        back_button("show:cart", "🔙 سبد خرید"),
        back_button("home:main", "🏠 منو"),
    ])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


# ============== کیبورد پنل ادمین ==============

def admin_main_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📊 داشبورد", callback_data="adm:dash")],
            [
                InlineKeyboardButton(text="🛍 محصولات", callback_data="adm:products"),
                InlineKeyboardButton(text="📂 دسته‌ها", callback_data="adm:categories"),
            ],
            [
                InlineKeyboardButton(text="📦 سفارشات فعال", callback_data="adm:orders"),
                InlineKeyboardButton(text="🗄 آرشیو", callback_data="adm:archive"),
            ],
            [
                InlineKeyboardButton(text="👥 کاربران", callback_data="adm:users"),
                InlineKeyboardButton(text="🎁 کد تخفیف", callback_data="adm:coupons"),
            ],
            [
                InlineKeyboardButton(text="📣 پیام همگانی", callback_data="adm:broadcast"),
                InlineKeyboardButton(text="💾 بکاپ", callback_data="adm:backup"),
            ],
            [InlineKeyboardButton(text="🚪 خروج", callback_data="adm:logout")],
        ]
    )


# ============== کیبوردهای ادمین - محصولات ==============

def admin_products_kb(products) -> InlineKeyboardMarkup:
    from utils import fa

    buttons = [[InlineKeyboardButton(text="➕ محصول جدید", callback_data="adm:addprod")]]
    for p in products:
        buttons.append([
            InlineKeyboardButton(
                text=f"⚙️ {p.name} ({fa(p.stock)})",
                callback_data=f"adm:delprod:{p.id}",
            )
        ])
    buttons.append([back_button("adm:back", "🔙 پنل")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def admin_categories_kb(categories) -> InlineKeyboardMarkup:
    buttons = [[InlineKeyboardButton(text="➕ دسته جدید", callback_data="adm:addcat")]]
    for c in categories:
        buttons.append([
            InlineKeyboardButton(
                text=f"⚙️ {c.icon} {c.name}",
                callback_data=f"adm:delcat:{c.id}",
            )
        ])
    buttons.append([back_button("adm:back", "🔙 پنل")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def admin_category_select_kb(categories) -> InlineKeyboardMarkup:
    buttons = []
    for c in categories:
        buttons.append([
            InlineKeyboardButton(
                text=f"{c.icon} {c.name}",
                callback_data=f"addprod:cat:{c.id}",
            )
        ])
    buttons.append([
        InlineKeyboardButton(text="➕ دسته جدید", callback_data="adm:addcat"),
    ])
    buttons.append([back_button("adm:products", "🔙 محصولات")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


# ============== کیبوردهای ادمین - سفارشات ==============

def admin_orders_kb(orders) -> InlineKeyboardMarkup:
    """لیست سفارشات فعال."""
    from utils import fa

    buttons = []
    for o in orders:
        status_label = get_status_label(o.status)
        buttons.append([
            InlineKeyboardButton(
                text=f"📋 {o.order_number} — {fa(f'{o.total_amount:,}')} — {status_label}",
                callback_data=f"adm:order:{o.id}",
            )
        ])
    buttons.append([
        InlineKeyboardButton(text="🗄 آرشیو", callback_data="adm:archive"),
        back_button("adm:back", "🔙 پنل"),
    ])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def admin_archive_kb(orders) -> InlineKeyboardMarkup:
    """لیست سفارشات آرشیو شده."""
    from utils import fa

    buttons = []
    for o in orders:
        status_label = get_status_label(o.status)
        buttons.append([
            InlineKeyboardButton(
                text=f"📦 {o.order_number} — {fa(f'{o.total_amount:,}')} — {status_label}",
                callback_data=f"adm:order:{o.id}",
            )
        ])
    buttons.append([
        InlineKeyboardButton(text="📦 فعال", callback_data="adm:orders"),
        back_button("adm:back", "🔙 پنل"),
    ])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def admin_order_actions_kb(order_id: int, status: str) -> InlineKeyboardMarkup:
    """عملیات روی سفارش بر اساس وضعیت فعلی."""
    buttons = []

    # تغییر وضعیت به مرحله بعد
    transitions = {
        OrderStatus.PENDING_PAYMENT.value: [
            ("✅ تایید پرداخت", f"adm:setstatus:{order_id}:paid"),
            ("❌ رد پرداخت", f"adm:reject:{order_id}"),
        ],
        OrderStatus.PAID.value: [
            ("🔄 شروع پردازش", f"adm:setstatus:{order_id}:processing"),
        ],
        OrderStatus.PROCESSING.value: [
            ("📦 آماده ارسال", f"adm:setstatus:{order_id}:ready_to_ship"),
        ],
        OrderStatus.READY_TO_SHIP.value: [
            ("🚚 ارسال شد", f"adm:setstatus:{order_id}:shipped"),
        ],
        OrderStatus.SHIPPED.value: [
            ("✅ تکمیل شد", f"adm:setstatus:{order_id}:completed"),
        ],
    }

    if status in transitions:
        for text, data in transitions[status]:
            buttons.append([InlineKeyboardButton(text=text, callback_data=data)])

    # دکمه لغو - در همه وضعیت‌ها
    if status not in (
        OrderStatus.CANCELLED.value,
        OrderStatus.COMPLETED.value,
    ):
        buttons.append([
            InlineKeyboardButton(text="❌ لغو سفارش", callback_data=f"adm:cancel:{order_id}"),
        ])

    # دکمه بازگشت به آرشیو یا فعال
    if status in ARCHIVED_ORDER_STATUSES:
        buttons.append([
            InlineKeyboardButton(text="🗄 آرشیو", callback_data="adm:archive"),
        ])
    else:
        buttons.append([
            InlineKeyboardButton(text="📦 فعال", callback_data="adm:orders"),
        ])
    buttons.append([back_button("adm:back", "🔙 پنل")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


# ============== کیبوردهای ادمین - سایر ==============

def admin_coupons_kb(coupons) -> InlineKeyboardMarkup:
    buttons = [[InlineKeyboardButton(text="➕ کد جدید", callback_data="adm:addcoupon")]]
    for c in coupons:
        buttons.append([
            InlineKeyboardButton(
                text=f"⚙️ {c.code}",
                callback_data=f"adm:delcoupon:{c.id}",
            )
        ])
    buttons.append([back_button("adm:back", "🔙 پنل")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def admin_approval_kb(order_id: int) -> InlineKeyboardMarkup:
    """دکمه‌های تایید/رد پرداخت (در پیام ادمین)."""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="✅ تایید",
                    callback_data=f"adm:approve:{order_id}",
                ),
                InlineKeyboardButton(
                    text="❌ رد",
                    callback_data=f"adm:reject:{order_id}",
                ),
            ],
        ]
    )


# ============== کیبورد بکاپ ==============

def admin_backup_kb(backups: list) -> InlineKeyboardMarkup:
    from utils import fa

    buttons = [
        [InlineKeyboardButton(text="📥 ساخت بکاپ جدید", callback_data="adm:backup:create")],
    ]
    if backups:
        buttons.append([InlineKeyboardButton(text="─── بکاپ‌ها ───", callback_data="noop")])
        for b in backups:
            size = int(b.stat().st_size / 1024)
            buttons.append([
                InlineKeyboardButton(
                    text=f"📁 {b.name} ({fa(size)}KB)",
                    callback_data=f"adm:backup:dl:{b.name}",
                ),
            ])
            buttons.append([
                InlineKeyboardButton(
                    text=f"🔄 بازیابی {b.name}",
                    callback_data=f"adm:backup:restore:{b.name}",
                ),
                InlineKeyboardButton(
                    text=f"🗑 حذف",
                    callback_data=f"adm:backup:del:{b.name}",
                ),
            ])
    buttons.append([back_button("adm:back", "🔙 پنل")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


# ============== توابع کمکی ==============

def get_status_label(status: str) -> str:
    """برگرداندن لیبل فارسی وضعیت."""
    from models import ORDER_STATUS_LABELS
    return ORDER_STATUS_LABELS.get(status, status)
