"""متن‌های ثابت و پیام‌های ربات"""
import config
from utils import fa


# ============== پیام‌های عمومی ==============
WELCOME = "🌟 به {shop} خوش آمدید!\n\nاز منوی زیر یکی را انتخاب کنید:"
WELCOME_BACK = "👋 خوش برگشتید {name}!"
CANCEL = "✅ عملیات لغو شد."
INVALID = "❌ ورودی نامعتبر. لطفاً دوباره تلاش کنید."
PERMISSION_DENIED = "🚫 شما دسترسی لازم را ندارید."
MAINTENANCE = "🔧 ربات در حال بروزرسانی است. لطفاً بعداً مراجعه کنید."
RATE_LIMITED = "⏱ تعداد درخواست‌های شما زیاد است. لطفاً کمی صبر کنید."

EMPTY_CART = "🛒 سبد خرید شما خالی است."
EMPTY_PRODUCTS = "📭 محصولی موجود نیست."
OUT_OF_STOCK = "❌ موجودی کافی نیست."
BACK = "🔙 بازگشت"


# ============== منوها ==============
MENU_CATALOG = "🛍 محصولات"
MENU_CART = "🛒 سبد خرید"
MENU_ORDERS = "📦 سفارش‌های من"
MENU_PROFILE = "👤 پروفایل"
MENU_ADMIN = "⚙️ پنل مدیریت"
BTN_CANCEL = "❌ انصراف"


# ============== محصولات ==============

def product_detail(p, qty_in_cart: int = 0) -> str:
    price = p.effective_price
    text = f"🛍 <b>{p.name}</b>\n\n"
    if p.description:
        text += f"{p.description}\n\n"
    text += f"💰 قیمت: {fa(f'{price:,}')} تومان\n"
    if p.is_on_sale:
        percent = int((1 - p.discount_price / p.price) * 100) if p.discount_price else 0
        text += f"🔥 تخفیف: {fa(percent)}٪\n"
    text += f"📦 موجودی: {fa(p.stock)}\n"
    if qty_in_cart:
        text += f"\n🛒 در سبد شما: {fa(qty_in_cart)} عدد"
    return text


def cart_text(items: list[tuple], total: int) -> str:
    if not items:
        return EMPTY_CART
    text = "🛒 <b>سبد خرید شما:</b>\n\n"
    for p, qty in items:
        price = p.effective_price
        sub = price * qty
        text += f"▫️ {p.name} × {fa(qty)} = {fa(f'{sub:,}')} تومان\n"
    text += f"\n💰 <b>مجموع: {fa(f'{total:,}')} تومان</b>"
    return text


# ============== سفارش ==============

# وضعیت‌ها از models.py لود می‌شوند
ORDER_STATUS_LABELS_FA = {
    "pending_payment": "⏳ در انتظار پرداخت",
    "paid": "💳 پرداخت شده",
    "processing": "🔄 در حال پردازش",
    "ready_to_ship": "📦 آماده ارسال",
    "shipped": "🚚 ارسال شده",
    "completed": "✅ تکمیل شده",
    "cancelled": "❌ لغو شده",
}


def get_status_label(status: str) -> str:
    return ORDER_STATUS_LABELS_FA.get(status, status)


ORDER_CREATED = "✅ سفارش شما با موفقیت ثبت شد!\n\n🔖 شماره: <code>{number}</code>\n💰 مبلغ: {amount} تومان\n\nپس از تایید توسط ادمین پردازش می‌شود."
ORDER_NOT_FOUND = "❌ سفارش یافت نشد."
ORDER_LIST_EMPTY = "📭 شما تاکنون سفارشی ثبت نکرده‌اید."


def order_text(o) -> str:
    return (
        f"🔖 <code>{o.order_number}</code>\n"
        f"📊 {get_status_label(o.status)}\n"
        f"💰 {fa(f'{o.total_amount:,}')} تومان\n"
        f"📅 {utils.fmt_date(o.created_at)}"
    )


# ============== پروفایل ==============

def profile_text(u) -> str:
    return (
        f"👤 <b>پروفایل شما</b>\n\n"
        f"🆔 آیدی: <code>{u.telegram_id}</code>\n"
        f"👤 نام: {u.full_name or '—'}\n"
        f"📞 تلفن: {u.phone or '—'}\n"
        f"💎 سطح: <b>{u.level.value if hasattr(u.level, 'value') else u.level}</b>\n"
        f"💰 کل خرید: {fa(f'{u.total_spent:,}')} تومان\n"
        f"📦 تعداد سفارش: {fa(u.orders_count)}"
    )


# ============== پرداخت ==============

def card_payment_info(amount: int) -> str:
    return (
        f"🏦 <b>پرداخت کارت به کارت</b>\n\n"
        f"💰 مبلغ: {fa(f'{amount:,}')} تومان\n\n"
        f"🏦 بانک: {config.BANK_NAME or '—'}\n"
        f"👤 صاحب: {config.CARD_OWNER_NAME or '—'}\n"
        f"💳 کارت: <code>{config.CARD_NUMBER or '—'}</code>\n"
        f"🔢 شبا: <code>{config.CARD_SHEBA or '—'}</code>\n\n"
        f"⚠️ پس از واریز:\n"
        f"1️⃣ تصویر فیش را ارسال کنید\n"
        f"2️⃣ شماره پیگیری را بفرستید (یا <code>ردشدن</code>)"
    )


PAYMENT_SUBMITTED = (
    "✅ فیش شما دریافت شد!\n\n"
    "🔖 شماره: <code>{number}</code>\n"
    "⏳ منتظر تایید ادمین باشید."
)
PAYMENT_REJECTED = (
    "❌ پرداخت شما رد شد.\n\n"
    "📌 دلیل: <b>{reason}</b>\n\n"
    "لطفاً دوباره تلاش کنید."
)
PAYMENT_APPROVED = "✅ پرداخت شما تایید شد!\n\nسفارش در حال پردازش است."


# ============== ادمین ==============

ADMIN_LOGIN_REQUIRED = "🔐 برای ورود به پنل، ابتدا /admin را بزنید."
ADMIN_PASSWORD_REQUEST = "🔐 لطفاً رمز عبور ادمین را وارد کنید:"
ADMIN_PASSWORD_WRONG = "❌ رمز اشتباه است. دوباره تلاش کنید."
ADMIN_LOGIN_OK = "✅ خوش آمدید! پنل مدیریت فعال شد."
ADMIN_LOGOUT_OK = "✅ از پنل مدیریت خارج شدید."
ADMIN_NOT_AUTHORIZED = "🚫 شما اجازه دسترسی به پنل مدیریت را ندارید."
ADMIN_ACTIVE = "🔓 شما در حال حاضر در پنل ادمین هستید."

ADMIN_PANEL = "⚙️ <b>پنل مدیریت</b>\n\nیک بخش را انتخاب کنید:"


def admin_dashboard_text(stats: dict) -> str:
    """متن داشبورد بر اساس آمار."""
    today_rev = fa(f"{stats.get('today_revenue', 0):,}")
    week_rev = fa(f"{stats.get('week_revenue', 0):,}")
    month_rev = fa(f"{stats.get('month_revenue', 0):,}")
    total_rev = fa(f"{stats.get('total_revenue', 0):,}")
    return (
        "📊 <b>داشبورد</b>\n\n"
        f"👥 کاربران: {fa(stats.get('users_count', 0))}\n"
        f"🛍 محصولات: {fa(stats.get('products_count', 0))}\n"
        f"📦 کل سفارشات: {fa(stats.get('total_orders', 0))}\n"
        f"⏳ در انتظار: {fa(stats.get('pending_orders', 0))}\n"
        f"\n💰 <b>آمار فروش</b>\n"
        f"📅 امروز: {today_rev} تومان\n"
        f"📆 این هفته: {week_rev} تومان\n"
        f"🗓 این ماه: {month_rev} تومان\n"
        f"💎 کل فروش: {total_rev} تومان"
    )


ADMIN_NEW_PAYMENT_NOTIFY = (
    "💳 <b>پرداخت جدید</b>\n\n"
    "🔖 سفارش: <code>{number}</code>\n"
    "👤 کاربر: {name} ({tid})\n"
    "💰 مبلغ: {amount} تومان\n"
    "🔢 پیگیری: <code>{track}</code>"
)


def admin_order_detail_text(order, items_text: str) -> str:
    """متن جزئیات سفارش برای ادمین."""
    return (
        f"📋 <b>سفارش {order.order_number}</b>\n\n"
        f"👤 {order.shipping_name}\n"
        f"📞 {order.shipping_phone}\n"
        f"📍 {order.shipping_city}, {order.shipping_province}\n"
        f"🏠 {order.shipping_address}\n"
        f"📮 {order.shipping_postal_code}\n"
        f"💰 {fa(f'{order.total_amount:,}')} تومان\n"
        f"📊 {get_status_label(order.status)}\n\n"
        f"<b>اقلام:</b>\n{items_text}"
    )


# بکاپ
BACKUP_CREATED = "✅ بکاپ ساخته شد: <code>{name}</code>\n📊 حجم: {size}"
BACKUP_LIST_EMPTY = "📭 بکاپی موجود نیست."
BACKUP_DELETED = "✅ بکاپ حذف شد."
BACKUP_RESTORED = "✅ بکاپ بازیابی شد!"
BACKUP_FAILED = "❌ خطا در عملیات بکاپ."


# ============== پیام‌های خطا ==============

ERR_DB = "⚠️ خطای داخلی. لطفاً دوباره تلاش کنید."
ERR_GENERAL = "❌ عملیات ناموفق بود. دوباره تلاش کنید."
SUCCESS_GENERAL = "✅ عملیات با موفقیت انجام شد."

# پیام‌های جدید برای navigation
BACK_TO_MAIN = "🏠 منوی اصلی"
BACK_TO_ADMIN = "🔙 پنل ادمین"
CANCEL_ACTION = "❌ لغو عملیات"


# Back handler
import utils
