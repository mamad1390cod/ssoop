# راهنمای Migration - حل مشکل "no such column"

اگر ربات خطایی مثل این می‌دهد:

```
sqlite3.OperationalError: no such column: users.first_name
sqlite3.OperationalError: no such column: admin_sessions.ip_address
sqlite3.OperationalError: no such column: categories.slug
```

یعنی دیتابیس شما با **schema قدیمی** ساخته شده ولی مدل‌های جدید ستون‌های بیشتری دارن.

## ✅ راه‌حل (۱ دقیقه)

### مرحله ۱: توقف ربات
ربات را با `Ctrl+C` متوقف کنید.

### مرحله ۲: اجرای Migration
```bash
python migrations.py
```

این اسکریپت:
- ✅ **خودکار بکاپ** می‌گیره (در `data/database.db.backup.<timestamp>`)
- ✅ ستون‌های **جدید** را اضافه می‌کنه (مثل `first_name`, `slug`, `ip_address`)
- ✅ جداول **جدید** را می‌سازه (مثل `cart_items`)
- ✅ **داده‌های موجود** حفظ می‌شوند
- ✅ **ایمن** است - چندبار اجرا کنید مشکلی پیش نمی‌آید

### مرحله ۳: اجرای ربات
```bash
python main.py
```

## 📋 خروجی نمونه Migration

```
📂 دیتابیس: data/database.db
📊 حجم فایل: 12.3 KB
💾 بکاپ ایجاد شد: data/database.db.backup.20260622_193952

📋 ساخت جداول جدید...
  ✅ cart_items

🔧 اضافه کردن ستون‌های جدید...
  ✅ users.first_name
  ✅ users.last_name
  ✅ users.email
  ✅ admin_sessions.ip_address
  ✅ admin_sessions.user_agent
  ✅ categories.slug
  ... (79 ستون)

🎯 مقداردهی اولیه...

==================================================
✅ Migration کامل شد!
  • 79 ستون اضافه شد
  • 0 ستون قبلاً وجود داشت
  • 3 جدول جدید ساخته شد
  • بکاپ در: data/database.db.backup.20260622_193952
==================================================
```

## 🔧 مشکلات خاص MySQL

این اسکریپت فقط برای SQLite کار می‌کند. اگر MySQL دارید:

```bash
# ایجاد migration خودکار با Alembic
alembic revision --autogenerate -m "add_missing_columns"
alembic upgrade head
```

## 🆘 اگر مشکل حل نشد

1. **بکاپ برگردانید:**
   ```bash
   cp data/database.db.backup.<timestamp> data/database.db
   ```

2. **از صفر شروع کنید** (داده‌ها از دست می‌رود!):
   ```bash
   rm data/database.db
   python main.py  # جداول جدید ساخته می‌شوند
   ```

3. **لاگ‌ها را بررسی کنید**:
   ```bash
   tail -f logs/errors.log
   ```

## ✅ Migration ایمن است

- ✅ **داده‌ها حفظ می‌شوند** - هیچ رکوردی حذف نمی‌شود
- ✅ **بکاپ خودکار** - قبل از هر تغییر بکاپ می‌گیرد
- ✅ **ایمن برای اجرای مجدد** - اگر ستونی قبلاً اضافه شده، رد می‌شود
- ✅ **فقط ستون‌های گم‌شده** اضافه می‌شوند

## 📊 Migration چه چیزی اضافه می‌کند؟

### ستون‌های جدید (۷۹ عدد):
- **users**: first_name, last_name, email, language_code, loyalty_points, is_verified, last_activity_at, metadata_json
- **categories**: slug, description, image_url, parent_id, updated_at
- **products**: short_description, cost_price, low_stock_threshold, track_inventory, is_new, is_vip_only, view_count, purchase_count, rating, reviews_count, images_json, weight_grams, dimensions, tags, discount_percent, discount_starts_at, discount_ends_at, meta_title, meta_description
- **orders**: subtotal, discount_amount, shipping_cost, tax_amount, final_amount, coupon_id, coupon_code, shipping_province, shipping_city, shipping_postal_code, payment_method, tracking_code, shipped_at, delivered_at, completed_at, cancelled_at, paid_at, customer_notes, admin_notes, cancel_reason, metadata_json, ip_address, user_agent, updated_at
- **payments**: reference_id, gateway, gateway_response, authority, card_number_hash, tracking_code_encrypted, receipt_id, ip_address, user_agent, verified_at, verified_by, verified_by_telegram_id, rejection_reason, rejected_at, invoice_number, invoice_url, notes, updated_at
- **admin_sessions**: ip_address, user_agent, last_used_at
- **coupons**: name, description, min_order_amount, max_discount_amount, usage_limit, usage_limit_per_user, valid_from, valid_until, is_vip_only, first_order_only, created_by, metadata_json, updated_at
- و بیشتر...

### جداول جدید (۳ عدد):
- **cart_items**: سبد خرید persistent
- ایندکس‌های مربوطه

## 🚀 خلاصه

```bash
# توقف ربات
Ctrl+C

# اجرای migration
python migrations.py

# اجرای مجدد ربات
python main.py
```

✅ تمام داده‌های شما حفظ می‌شود و ربات بدون خطا کار خواهد کرد!
