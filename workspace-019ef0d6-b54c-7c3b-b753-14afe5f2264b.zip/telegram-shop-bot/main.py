"""
ربات فروشگاهی تلگرام - نقطه ورود اصلی

اجرا: python main.py
"""
import asyncio
import logging
import sys
from contextlib import asynccontextmanager
from pathlib import Path

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage

import config
from admin_panel import admin_router
from cart_service import CartService, cart_cleanup_task
from database import close_db, init_db
from error_handler import ErrorHandlerMiddleware
from handlers import user_router
from loguru import logger as loguru_logger


def setup_logging() -> None:
    """تنظیم سیستم لاگ."""
    log_dir = Path(config.LOGS_DIR)
    log_dir.mkdir(parents=True, exist_ok=True)

    loguru_logger.remove()
    loguru_logger.add(
        sys.stderr,
        format=(
            "<green>{time:YYYY-MM-DD HH:mm:ss}</green> | "
            "<level>{level: <8}</level> | "
            "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> | "
            "<level>{message}</level>"
        ),
        level=config.LOG_LEVEL,
        colorize=True,
    )
    loguru_logger.add(
        log_dir / "bot.log",
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {message}",
        level="INFO",
        rotation="10 MB",
        retention="7 days",
        encoding="utf-8",
    )
    loguru_logger.add(
        log_dir / "errors.log",
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {message}",
        level="ERROR",
        rotation="10 MB",
        retention="30 days",
        encoding="utf-8",
    )

    logging.basicConfig(level=logging.INFO)
    for name in ("uvicorn", "aiogram", "asyncio"):
        logging.getLogger(name).setLevel(logging.WARNING)


async def setup_bot() -> tuple[Bot, Dispatcher]:
    """ساخت ربات و dispatcher."""
    bot = Bot(
        token=config.BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    storage = MemoryStorage()
    dp = Dispatcher(storage=storage)

    # Middleware - error handler اول اجرا شود
    error_middleware = ErrorHandlerMiddleware()
    dp.message.middleware(error_middleware)
    dp.callback_query.middleware(error_middleware)

    # Routers - ادمین اول
    dp.include_router(admin_router)
    dp.include_router(user_router)

    return bot, dp


# تسک‌های پس‌زمینه
_background_tasks: list[asyncio.Task] = []


async def _run_background_tasks():
    """اجرای تسک‌های پس‌زمینه."""
    _background_tasks.append(asyncio.create_task(cart_cleanup_task()))
    loguru_logger.info("✅ تسک‌های پس‌زمینه شروع شدند")


async def main() -> None:
    """اجرای ربات."""
    global _background_tasks
    setup_logging()
    loguru_logger.info("🤖 ربات در حال راه‌اندازی...")

    from database import db_info
    info = db_info()
    loguru_logger.info(f"📦 دیتابیس: {info['type']}")

    # اجرای خودکار migration در صورت نیاز (فقط SQLite)
    if config.DATABASE_TYPE == "sqlite":
        try:
            from migrations import migrate
            # فقط اگر DB وجود داره
            db_path = config.DATABASE_URL.replace("sqlite:///", "", 1).replace("sqlite://", "", 1)
            if Path(db_path).exists():
                loguru_logger.info("🔧 بررسی و migration دیتابیس...")
                migrate()
        except Exception as e:
            loguru_logger.warning(f"Auto migration skipped: {e}")

    await init_db()
    loguru_logger.info("✅ دیتابیس آماده شد")

    # پاکسازی اولیه
    try:
        await CartService.cleanup_all_expired_carts()
    except Exception as e:
        loguru_logger.warning(f"Initial cleanup failed: {e}")

    bot, dp = await setup_bot()
    loguru_logger.info(f"🏪 فروشگاه: {config.SHOP_NAME}")
    loguru_logger.info(f"👥 ادمین‌ها: {config.ADMIN_IDS}")

    # شروع تسک‌های پس‌زمینه
    await _run_background_tasks()

    try:
        loguru_logger.info("✅ ربات شروع به کار کرد. Ctrl+C برای توقف.")
        await dp.start_polling(
            bot, allowed_updates=["message", "callback_query", "inline_query"]
        )
    finally:
        loguru_logger.info("در حال توقف...")
        for task in _background_tasks:
            task.cancel()
        for task in _background_tasks:
            try:
                await task
            except asyncio.CancelledError:
                pass
        await close_db()
        loguru_logger.info("👋 ربات متوقف شد")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n👋 ربات متوقف شد.")
    except Exception as e:
        print(f"\n❌ خطای مرگبار: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
