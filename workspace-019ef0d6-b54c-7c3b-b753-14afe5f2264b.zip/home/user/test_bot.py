"""تست کلی پروژه"""
import asyncio
import os
import sys

sys.path.insert(0, '/home/user/telegram-shop-bot')
os.chdir('/home/user/telegram-shop-bot')

from dotenv import load_dotenv
load_dotenv('.env.example')

with open('.env', 'w') as f:
    f.write('''BOT_TOKEN=123456:TEST_TOKEN
ADMIN_IDS=123456
ADMIN_CHAT_ID=123456
ADMIN_PASSWORD=test1234
SHOP_NAME=تست
DATABASE_TYPE=sqlite
DATABASE_URL=sqlite:///data/database.db
''')

load_dotenv('.env', override=True)

print('=' * 50)
print('تست بارگذاری ماژول‌ها')
print('=' * 50)

import config
print(f'✅ config.py loaded')
print(f'   BOT_TOKEN: {config.BOT_TOKEN[:10]}...')
print(f'   ADMIN_IDS: {config.ADMIN_IDS}')
print(f'   DATABASE_TYPE: {config.DATABASE_TYPE}')
print(f'   is_admin(123456): {config.is_admin(123456)}')

import models
print(f'✅ models.py loaded')

import database
print(f'✅ database.py loaded')

import utils
print(f'✅ utils.py loaded')
print(f'   fa(123456): {utils.fa(123456)}')
print(f'   gen_order_number(): {utils.gen_order_number()}')

hashed = utils.hash_password('test1234')
print(f'   hash_password works: {utils.verify_password("test1234", hashed)}')

import texts
print(f'✅ texts.py loaded')

import keyboards
print(f'✅ keyboards.py loaded')

import payments
print(f'✅ payments.py loaded')

import admin_panel
print(f'✅ admin_panel.py loaded')

import handlers
print(f'✅ handlers.py loaded')


async def test_db():
    print()
    print('=' * 50)
    print('تست دیتابیس')
    print('=' * 50)

    if os.path.exists('data/database.db'):
        os.remove('data/database.db')

    await database.init_db()
    print('✅ init_db() موفق')

    from sqlalchemy import select
    async with database.get_session() as s:
        c = models.Category(name='موبایل', icon='📱', sort_order=1)
        s.add(c)

    async with database.get_session() as s:
        cat = (await s.execute(select(models.Category).where(models.Category.name=='موبایل'))).scalar_one()
        p = models.Product(name='آیفون', price=50000000, stock=5, category_id=cat.id)
        s.add(p)

    async with database.get_session() as s:
        products = (await s.execute(select(models.Product))).scalars().all()
        print(f'✅ Products in DB: {len(products)}')
        for p in products:
            print(f'   - {p.name}: {p.price:,} تومان')

    # تست سبد خرید
    utils.get_cart(123456)[products[0].id] = 2
    async with database.get_session() as s:
        products_map = {p.id: p for p in (await s.execute(select(models.Product))).scalars().all()}
    total = 0
    for pid, qty in utils.get_cart(123456).items():
        if pid in products_map:
            total += products_map[pid].price * qty
    print(f'✅ Cart total: {total:,} تومان = {utils.fa(f"{total:,}")}')

    # تست بکاپ
    import shutil
    backup_path = config.BACKUPS_DIR / 'backup_test.db'
    shutil.copy2(config.DATA_DIR / 'database.db', backup_path)
    print(f'✅ بکاپ ساخته شد: {backup_path.name} ({backup_path.stat().st_size} bytes)')

    # تست سشن ادمین
    print()
    print('=' * 50)
    print('تست احراز هویت ادمین')
    print('=' * 50)

    sess = await admin_panel.create_session(123456)
    print(f'✅ Session created: token={sess.token[:20]}...')
    print(f'✅ is_authenticated(123456): {await admin_panel.is_authenticated(123456)}')
    await admin_panel.destroy_session(123456)
    print(f'✅ Session destroyed')

    # تست کیبوردها
    print()
    print('=' * 50)
    print('تست کیبوردها')
    print('=' * 50)
    admin_kb = keyboards.admin_main_kb()
    print(f'✅ Admin keyboard: {len(admin_kb.inline_keyboard)} rows')
    user_kb = keyboards.main_menu(123456)
    print(f'✅ User keyboard (admin): {len(user_kb.keyboard)} rows')
    user_kb = keyboards.main_menu(999)  # غیر ادمین
    print(f'✅ User keyboard (non-admin): {len(user_kb.keyboard)} rows')

    # تست تولید کد تخفیف
    print()
    print('=' * 50)
    print('تست کد تخفیف')
    print('=' * 50)
    code = utils.gen_coupon_code()
    print(f'✅ Coupon code: {code}')

    print()
    print('🎉 تمام تست‌ها موفق!')


asyncio.run(test_db())
