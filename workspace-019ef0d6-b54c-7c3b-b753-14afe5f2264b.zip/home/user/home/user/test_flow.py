"""تست جریان کامل checkout و admin"""
import asyncio
import os
import sys

sys.path.insert(0, '/home/user/telegram-shop-bot')
os.chdir('/home/user/telegram-shop-bot')

from dotenv import load_dotenv
load_dotenv('.env.example')

with open('.env', 'w') as f:
    f.write('''BOT_TOKEN=123:test
ADMIN_IDS=123456
ADMIN_PASSWORD=test123
''')

load_dotenv('.env', override=True)

import config
import utils
import models
import database
import admin_panel
import handlers


async def test():
    """تست کامل جریان‌ها"""
    print('=' * 60)
    print('تست توابع جدید')
    print('=' * 60)

    # 1. تست is_skip
    skip_tests = [
        ("-", True),
        ("ردشدن", True),
        ("رد شدن", True),
        ("بیخیال", True),
        ("skip", True),
        ("ندارد", True),
        ("REDSHADN", True),  # حروف بزرگ
        ("  ردشدن  ", True),  # با فاصله
        ("سلام", False),
        ("", False),
        (None, False),
    ]
    for text, expected in skip_tests:
        result = utils.is_skip(text)
        status = "✅" if result == expected else "❌"
        print(f"  {status} is_skip({text!r}): {result} (انتظار: {expected})")

    # 2. تست get_text
    class M:
        text = None
    print()
    M.text = None
    print(f"  ✅ get_text(text=None): {utils.get_text(M())!r}")
    M.text = "  hello  "
    print(f"  ✅ get_text(با فاصله): {utils.get_text(M())!r}")
    M.text = ""
    print(f"  ✅ get_text(خالی): {utils.get_text(M())!r}")

    # 3. تست checkout states
    print()
    print(f"  ✅ CheckoutStates.receipt: {handlers.CheckoutStates.receipt}")
    print(f"  ✅ CheckoutStates.tracking_code: {handlers.CheckoutStates.tracking_code}")

    # 4. تست دیتابیس
    print()
    print('=' * 60)
    print('تست دیتابیس')
    print('=' * 60)

    if os.path.exists('data/database.db'):
        os.remove('data/database.db')
    await database.init_db()

    from sqlalchemy import select
    async with database.get_session() as s:
        # ساخت دسته
        cat = models.Category(name='تست', icon='🧪', sort_order=1)
        s.add(cat)
        # ساخت محصول
        result = await s.execute(select(models.Category))
        cat = result.scalar_one()
        p = models.Product(
            name='محصول تست', price=100000, stock=10,
            category_id=cat.id, description='توضیحات تست'
        )
        s.add(p)

    # 5. تست ساخت سفارش با فیش و شماره پیگیری
    print()
    print('=' * 60)
    print('تست ساخت سفارش')
    print('=' * 60)

    async with database.get_session() as s:
        result = await s.execute(select(models.User).where(models.User.telegram_id == 123))
        user = result.scalar_one_or_none()
        if not user:
            user = models.User(
                telegram_id=123, username='test', full_name='کاربر تست'
            )
            s.add(user)
            await s.flush()
            await s.refresh(user)

        result = await s.execute(select(models.Product))
        product = result.scalar_one()

        import json
        order = models.Order(
            order_number=utils.gen_order_number(),
            user_id=user.id,
            items_json=json.dumps([
                {"id": product.id, "name": product.name, "qty": 2, "price": product.price}
            ], ensure_ascii=False),
            subtotal=product.price * 2,
            discount_amount=0,
            total=product.price * 2,
            status="pending_payment",
            payment_method="card_to_card",
            tracking_code="TEST12345",
            shipping_name="علی احمدی",
            shipping_phone="+989123456789",
            shipping_address="تهران، خیابان آزادی",
            receipt_file_id="AgACAgIAAxk...",
        )
        s.add(order)
        await s.flush()
        order_id = order.id
        order_num = order.order_number
        print(f"  ✅ سفارش ساخته شد: {order_num}")
        print(f"     tracking_code: {order.tracking_code}")
        print(f"     receipt_file_id: {order.receipt_file_id[:20]}...")

        # ساخت پرداخت
        payment = models.Payment(
            order_id=order_id,
            user_id=user.id,
            method="card_to_card",
            status="pending",
            amount=order.total,
            transaction_id=f"CC-{order_num}",
            tracking_code_encrypted=utils.encrypt("TEST12345"),
            receipt_file_id="AgACAgIAAxk...",
            receipt_hash=utils.file_hash(b"test data"),
        )
        s.add(payment)

    print()
    print('🎉 تمام تست‌های جریان موفق!')
    print()
    print('خلاصه تغییرات:')
    print('  ✅ "-", "ردشدن", "رد شدن", "بیخیال", "skip", "ندارد" همگی به عنوان "رد شدن" شناخته می‌شوند')
    print('  ✅ تمام ورودی‌های خالی بررسی می‌شوند')
    print('  ✅ شماره پیگیری اکنون جمع‌آوری می‌شود')
    print('  ✅ فیش + شماره پیگیری هر دو ذخیره می‌شوند')
    print('  ✅ اگر کاربر در مرحله فیش عکس نفرستد، پیام خطا می‌گیرد')


asyncio.run(test())
